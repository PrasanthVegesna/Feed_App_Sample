// NWJS compatibility layer - replaces electron functionality
window.nwAPI = {
  // Database operations
  database: {
    executeQuery: async (query, params = []) => {
      // This will be handled by the NWJS backend
      return new Promise((resolve, reject) => {
        // Send message to NWJS backend
        if (window.nw && window.nw.require) {
          const db = window.nw.require('./public/database.js');
          db.executeQuery(query, params)
            .then(resolve)
            .catch(reject);
        } else {
          reject(new Error('NWJS not available'));
        }
      });
    },
    
    getAllRecords: async (table) => {
      return new Promise((resolve, reject) => {
        if (window.nw && window.nw.require) {
          const db = window.nw.require('./public/database.js');
          db.getAllRecords(table)
            .then(resolve)
            .catch(reject);
        } else {
          reject(new Error('NWJS not available'));
        }
      });
    },
    
    insertRecord: async (table, data) => {
      return new Promise((resolve, reject) => {
        if (window.nw && window.nw.require) {
          const db = window.nw.require('./public/database.js');
          db.insertRecord(table, data)
            .then(resolve)
            .catch(reject);
        } else {
          reject(new Error('NWJS not available'));
        }
      });
    },
    
    updateRecord: async (table, data, id) => {
      return new Promise((resolve, reject) => {
        if (window.nw && window.nw.require) {
          const db = window.nw.require('./public/database.js');
          db.updateRecord(table, data, id)
            .then(resolve)
            .catch(reject);
        } else {
          reject(new Error('NWJS not available'));
        }
      });
    },
    
    deleteRecord: async (table, id) => {
      return new Promise((resolve, reject) => {
        if (window.nw && window.nw.require) {
          const db = window.nw.require('./public/database.js');
          db.deleteRecord(table, id)
            .then(resolve)
            .catch(reject);
        } else {
          reject(new Error('NWJS not available'));
        }
      });
    }
  },

  // File operations
  dialog: {
    showSaveDialog: (options) => {
      return new Promise((resolve) => {
        if (window.nw) {
          const input = document.createElement('input');
          input.type = 'file';
          input.nwsaveas = options.defaultPath || 'export.pdf';
          input.accept = options.filters ? options.filters.map(f => f.extensions.map(e => '.' + e).join(',')).join(',') : '';
          
          input.addEventListener('change', (e) => {
            const filePath = e.target.value;
            resolve({ filePath, canceled: !filePath });
          });
          
          input.click();
        } else {
          resolve({ canceled: true });
        }
      });
    }
  },

  // Window operations
  shell: {
    openExternal: (url) => {
      if (window.nw) {
        window.nw.Shell.openExternal(url);
      } else {
        window.open(url, '_blank');
      }
    }
  }
};

// Initialize database when app starts
if (window.nw && window.nw.require) {
  const db = window.nw.require('./public/database.js');
  db.initDatabase().catch(console.error);
}
