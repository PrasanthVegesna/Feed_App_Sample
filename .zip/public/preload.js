const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Database operations
  dbExecuteQuery: (query, params) => ipcRenderer.invoke('db-execute-query', query, params),
  dbGetAll: (table, whereClause, params) => ipcRenderer.invoke('db-get-all', table, whereClause, params),
  dbInsert: (table, data) => ipcRenderer.invoke('db-insert', table, data),
  dbUpdate: (table, data, whereClause, params) => ipcRenderer.invoke('db-update', table, data, whereClause, params),
  dbDelete: (table, whereClause, params) => ipcRenderer.invoke('db-delete', table, whereClause, params),
  
  // MongoDB operations
  mongoSync: () => ipcRenderer.invoke('mongo-sync'),
  mongoRestore: () => ipcRenderer.invoke('mongo-restore'),
  mongoTest: () => ipcRenderer.invoke('mongo-test'),
  
  // File operations
  showSaveDialog: (options) => ipcRenderer.invoke('show-save-dialog', options),
  showOpenDialog: (options) => ipcRenderer.invoke('show-open-dialog', options),
});
