const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

let db = null;

const getDbPath = () => {
  const userDataPath = process.env.APPDATA || 
    (process.platform === 'darwin' ? process.env.HOME + '/Library/Preferences' : 
     process.env.HOME + '/.local/share');
  
  const appDataDir = path.join(userDataPath, 'inventory-management-app');
  
  if (!fs.existsSync(appDataDir)) {
    fs.mkdirSync(appDataDir, { recursive: true });
  }
  
  return path.join(appDataDir, 'inventory.db');
};

const initDatabase = async () => {
  return new Promise((resolve, reject) => {
    const dbPath = getDbPath();
    console.log('Database path:', dbPath);
    
    // Only delete database if RESET_DB environment variable is set
    if (process.env.RESET_DB === 'true' && require('fs').existsSync(dbPath)) {
      try {
        require('fs').unlinkSync(dbPath);
        console.log('Deleted existing database for fresh start');
      } catch (error) {
        console.error('Error deleting existing database:', error);
      }
    }
    
    db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error('Database connection error:', err);
        reject(err);
        return;
      }
      
      console.log('Connected to SQLite database');
      createTables()
        .then(resolve)
        .catch(reject);
    });
  });
};

const createTables = async () => {
  const tables = [
    // Settings table
    `CREATE TABLE IF NOT EXISTS settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      key TEXT UNIQUE NOT NULL,
      value TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`,
    
    // Categories table
    `CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`,
    
    // Products table
    `CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      category_id TEXT,
      unit TEXT NOT NULL DEFAULT 'kg',
      purchase_price DECIMAL(10,2) NOT NULL DEFAULT 0,
      selling_price DECIMAL(10,2) NOT NULL DEFAULT 0,
      current_stock DECIMAL(10,2) NOT NULL DEFAULT 0,
      min_stock_level DECIMAL(10,2) NOT NULL DEFAULT 0,
      gst_rate DECIMAL(5,2) NOT NULL DEFAULT 0,
      hsn_code TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (category_id) REFERENCES categories (id)
    )`,
    
    // Customers table
    `CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      address TEXT,
      gstin TEXT,
      state_code TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`,
    
    // Suppliers table
    `CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      address TEXT,
      gstin TEXT,
      state_code TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`,
    
    // Sales table
    `CREATE TABLE IF NOT EXISTS sales (
      id TEXT PRIMARY KEY,
      customer_id TEXT,
      invoice_number TEXT UNIQUE NOT NULL,
      sale_date DATE NOT NULL,
      subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
      cgst_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      sgst_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      igst_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      payment_status TEXT NOT NULL DEFAULT 'pending',
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES customers (id)
    )`,
    
    // Sale items table
    `CREATE TABLE IF NOT EXISTS sale_items (
      id TEXT PRIMARY KEY,
      sale_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      quantity DECIMAL(10,2) NOT NULL,
      unit_price DECIMAL(10,2) NOT NULL,
      gst_rate DECIMAL(5,2) NOT NULL DEFAULT 0,
      total_amount DECIMAL(10,2) NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (sale_id) REFERENCES sales (id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products (id)
    )`,
    
    // Purchases table
    `CREATE TABLE IF NOT EXISTS purchases (
      id TEXT PRIMARY KEY,
      supplier_id TEXT,
      invoice_number TEXT,
      purchase_date DATE NOT NULL,
      total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      payment_status TEXT NOT NULL DEFAULT 'pending',
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
    )`,
    
    // Purchase items table
    `CREATE TABLE IF NOT EXISTS purchase_items (
      id TEXT PRIMARY KEY,
      purchase_id TEXT NOT NULL,
      product_id TEXT NOT NULL,
      quantity DECIMAL(10,2) NOT NULL,
      unit_price DECIMAL(10,2) NOT NULL,
      total_amount DECIMAL(10,2) NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (purchase_id) REFERENCES purchases (id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products (id)
    )`
  ];
  
  for (const tableQuery of tables) {
    await executeQuery(tableQuery);
  }
  
  // Insert default settings
  await insertDefaultSettings();
  
  // Insert default categories
  await insertDefaultCategories();
  
  console.log('Database tables created successfully');
};

const insertDefaultSettings = async () => {
  const defaultSettings = [
    { key: 'company_name', value: 'Your Fish Feed Company' },
    { key: 'company_address', value: 'Your Company Address' },
    { key: 'company_phone', value: 'Your Phone Number' },
    { key: 'company_email', value: 'your.email@company.com' },
    { key: 'gstin', value: '' },
    { key: 'state_code', value: '27' }, // Default to Maharashtra
    { key: 'default_gst_rate', value: '18' },
    { key: 'currency_symbol', value: '₹' },
    { key: 'mongodb_uri', value: '' },
    { key: 'mongodb_database', value: 'inventory_management' }
  ];
  
  for (const setting of defaultSettings) {
    try {
      await executeQuery(
        'INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)',
        [setting.key, setting.value]
      );
    } catch (error) {
      console.error('Error inserting default setting:', error);
    }
  }
};

const insertDefaultCategories = async () => {
  const defaultCategories = [
    { id: uuidv4(), name: 'Fish Feed', description: 'Fish feed products' },
    { id: uuidv4(), name: 'Shrimp Feed', description: 'Shrimp feed products' },
    { id: uuidv4(), name: 'Supplements', description: 'Feed supplements and additives' },
    { id: uuidv4(), name: 'Equipment', description: 'Farming equipment and tools' }
  ];
  
  for (const category of defaultCategories) {
    try {
      // Check if category with same name already exists
      const existingCategory = await new Promise((resolve, reject) => {
        db.get('SELECT id FROM categories WHERE name = ?', [category.name], (err, row) => {
          if (err) reject(err);
          else resolve(row);
        });
      });
      
      if (!existingCategory) {
        await executeQuery(
          'INSERT INTO categories (id, name, description) VALUES (?, ?, ?)',
          [category.id, category.name, category.description]
        );
      }
    } catch (error) {
      console.error('Error inserting default category:', error);
    }
  }
};

const executeQuery = (query, params = []) => {
  return new Promise((resolve, reject) => {
    if (!db) {
      reject(new Error('Database not initialized'));
      return;
    }
    
    db.run(query, params, function(err) {
      if (err) {
        console.error('SQL Error:', err);
        reject(err);
      } else {
        resolve({ lastID: this.lastID, changes: this.changes });
      }
    });
  });
};

const getAllRecords = (table, whereClause = '', params = []) => {
  return new Promise((resolve, reject) => {
    if (!db) {
      reject(new Error('Database not initialized'));
      return;
    }
    
    let query = `SELECT * FROM ${table}`;
    if (whereClause) {
      query += ` WHERE ${whereClause}`;
    }
    
    // Check if table has created_at column, if not, don't order by it
    db.all(`PRAGMA table_info(${table})`, (err, columns) => {
      if (err) {
        console.error('Error getting table info:', err);
        reject(err);
        return;
      }
      
      const hasCreatedAt = columns.some(col => col.name === 'created_at');
      if (hasCreatedAt) {
        query += ' ORDER BY created_at DESC';
      }
      
      db.all(query, params, (err, rows) => {
        if (err) {
          console.error('SQL Error:', err);
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  });
};

const insertRecord = async (table, data) => {
  const columns = Object.keys(data);
  const values = Object.values(data);
  const placeholders = columns.map(() => '?').join(', ');
  
  const query = `INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders})`;
  return await executeQuery(query, values);
};

const updateRecord = async (table, data, whereClause, params = []) => {
  const updates = Object.keys(data).map(key => `${key} = ?`).join(', ');
  const values = [...Object.values(data), ...params];
  
  const query = `UPDATE ${table} SET ${updates}, updated_at = CURRENT_TIMESTAMP WHERE ${whereClause}`;
  return await executeQuery(query, values);
};

const deleteRecord = async (table, whereClause, params = []) => {
  const query = `DELETE FROM ${table} WHERE ${whereClause}`;
  return await executeQuery(query, params);
};

module.exports = {
  initDatabase,
  executeQuery,
  getAllRecords,
  insertRecord,
  updateRecord,
  deleteRecord
};
