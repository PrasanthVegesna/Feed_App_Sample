const { MongoClient } = require('mongodb');
const { getAllRecords, executeQuery } = require('./database');
require('dotenv').config();

let mongoClient = null;
let mongoDb = null;

const connectToMongoDB = async () => {
  const mongoUri = process.env.MONGODB_URI;
  const dbName = process.env.MONGODB_DATABASE || 'inventory_management';
  
  if (!mongoUri) {
    throw new Error('MongoDB URI not configured. Please set MONGODB_URI in .env file.');
  }
  
  if (!mongoClient) {
    mongoClient = new MongoClient(mongoUri);
    await mongoClient.connect();
    mongoDb = mongoClient.db(dbName);
    console.log('Connected to MongoDB Atlas');
  }
  
  return mongoDb;
};

const testMongoConnection = async () => {
  try {
    const db = await connectToMongoDB();
    await db.admin().ping();
    return { success: true, message: 'MongoDB connection successful' };
  } catch (error) {
    console.error('MongoDB connection test failed:', error);
    return { success: false, message: error.message };
  }
};

const syncToMongoDB = async () => {
  try {
    const db = await connectToMongoDB();
    
    const tables = [
      'settings', 'categories', 'products', 'customers', 
      'suppliers', 'sales', 'sale_items', 'purchases', 'purchase_items'
    ];
    
    const syncData = {
      timestamp: new Date().toISOString(),
      data: {}
    };
    
    for (const table of tables) {
      const records = await getAllRecords(table);
      syncData.data[table] = records;
    }
    
    // Store backup in MongoDB
    await db.collection('backups').insertOne(syncData);
    
    // Also maintain latest sync in a separate collection
    await db.collection('latest_sync').replaceOne(
      { type: 'latest' },
      { type: 'latest', ...syncData },
      { upsert: true }
    );
    
    console.log('Data synced to MongoDB successfully');
    return { success: true, message: 'Data synced to MongoDB successfully', timestamp: syncData.timestamp };
    
  } catch (error) {
    console.error('MongoDB sync failed:', error);
    return { success: false, message: error.message };
  }
};

const restoreFromMongoDB = async () => {
  try {
    const db = await connectToMongoDB();
    
    // Get latest backup
    const latestBackup = await db.collection('latest_sync').findOne({ type: 'latest' });
    
    if (!latestBackup || !latestBackup.data) {
      throw new Error('No backup data found in MongoDB');
    }
    
    const tables = Object.keys(latestBackup.data);
    
    // Disable foreign key constraints
    await executeQuery('PRAGMA foreign_keys = OFF');
    
    try {
      // Clear existing data
      for (const table of tables) {
        await executeQuery(`DELETE FROM ${table}`);
      }
      
      // Restore data
      for (const table of tables) {
        const records = latestBackup.data[table];
        
        if (records && records.length > 0) {
          for (const record of records) {
            const columns = Object.keys(record);
            const values = Object.values(record);
            const placeholders = columns.map(() => '?').join(', ');
            
            const query = `INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders})`;
            await executeQuery(query, values);
          }
        }
      }
      
      console.log('Data restored from MongoDB successfully');
      return { 
        success: true, 
        message: 'Data restored from MongoDB successfully', 
        timestamp: latestBackup.timestamp 
      };
      
    } finally {
      // Re-enable foreign key constraints
      await executeQuery('PRAGMA foreign_keys = ON');
    }
    
  } catch (error) {
    console.error('MongoDB restore failed:', error);
    return { success: false, message: error.message };
  }
};

const getAllBackups = async () => {
  try {
    const db = await connectToMongoDB();
    
    const backups = await db.collection('backups')
      .find({}, { projection: { timestamp: 1, _id: 1 } })
      .sort({ timestamp: -1 })
      .limit(50)
      .toArray();
    
    return { success: true, backups };
    
  } catch (error) {
    console.error('Failed to get backups:', error);
    return { success: false, message: error.message };
  }
};

const restoreFromSpecificBackup = async (backupId) => {
  try {
    const db = await connectToMongoDB();
    const { ObjectId } = require('mongodb');
    
    const backup = await db.collection('backups').findOne({ _id: new ObjectId(backupId) });
    
    if (!backup || !backup.data) {
      throw new Error('Backup not found');
    }
    
    const tables = Object.keys(backup.data);
    
    // Disable foreign key constraints
    await executeQuery('PRAGMA foreign_keys = OFF');
    
    try {
      // Clear existing data
      for (const table of tables) {
        await executeQuery(`DELETE FROM ${table}`);
      }
      
      // Restore data
      for (const table of tables) {
        const records = backup.data[table];
        
        if (records && records.length > 0) {
          for (const record of records) {
            const columns = Object.keys(record);
            const values = Object.values(record);
            const placeholders = columns.map(() => '?').join(', ');
            
            const query = `INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders})`;
            await executeQuery(query, values);
          }
        }
      }
      
      return { 
        success: true, 
        message: 'Data restored from specific backup successfully', 
        timestamp: backup.timestamp 
      };
      
    } finally {
      // Re-enable foreign key constraints
      await executeQuery('PRAGMA foreign_keys = ON');
    }
    
  } catch (error) {
    console.error('Specific backup restore failed:', error);
    return { success: false, message: error.message };
  }
};

module.exports = {
  testMongoConnection,
  syncToMongoDB,
  restoreFromMongoDB,
  getAllBackups,
  restoreFromSpecificBackup
};
