const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');
const { initDatabase, executeQuery, getAllRecords, insertRecord, updateRecord, deleteRecord } = require('./database');
const { syncToMongoDB, restoreFromMongoDB, testMongoConnection } = require('./mongodb');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      preload: path.join(__dirname, 'preload.js'),
    },
    show: true, // Show window immediately
  });

  const startUrl = isDev 
    ? 'http://localhost:3000' 
    : `file://${path.join(__dirname, '../build/index.html')}`;
  
  mainWindow.loadURL(startUrl);
  
  console.log('Loading URL:', startUrl);
  console.log('isDev:', isDev);

  mainWindow.once('ready-to-show', () => {
    console.log('Window ready to show');
    mainWindow.show();
    
    // Initialize database on app start
    initDatabase().catch(console.error);
  });

  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription) => {
    console.error('Failed to load:', errorCode, errorDescription);
  });

  mainWindow.on('closed', () => {
    console.log('Window closed');
    mainWindow = null;
  });
}

app.on('ready', createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});

// Database IPC handlers
ipcMain.handle('db-execute-query', async (event, query, params) => {
  return await executeQuery(query, params);
});

ipcMain.handle('db-get-all', async (event, table, whereClause, params) => {
  return await getAllRecords(table, whereClause, params);
});

ipcMain.handle('db-insert', async (event, table, data) => {
  return await insertRecord(table, data);
});

ipcMain.handle('db-update', async (event, table, data, whereClause, params) => {
  return await updateRecord(table, data, whereClause, params);
});

ipcMain.handle('db-delete', async (event, table, whereClause, params) => {
  return await deleteRecord(table, whereClause, params);
});

// MongoDB sync handlers
ipcMain.handle('mongo-sync', async (event) => {
  return await syncToMongoDB();
});

ipcMain.handle('mongo-restore', async (event) => {
  return await restoreFromMongoDB();
});

ipcMain.handle('mongo-test', async (event) => {
  return await testMongoConnection();
});

// File dialog handlers
ipcMain.handle('show-save-dialog', async (event, options) => {
  const result = await dialog.showSaveDialog(mainWindow, options);
  return result;
});

ipcMain.handle('show-open-dialog', async (event, options) => {
  const result = await dialog.showOpenDialog(mainWindow, options);
  return result;
});
