// GST calculation utilities for Indian tax system

// State codes for GST calculation
export const STATE_CODES = {
  '01': 'Jammu and Kashmir',
  '02': 'Himachal Pradesh',
  '03': 'Punjab',
  '04': 'Chandigarh',
  '05': 'Uttarakhand',
  '06': 'Haryana',
  '07': 'Delhi',
  '08': 'Rajasthan',
  '09': 'Uttar Pradesh',
  '10': 'Bihar',
  '11': 'Sikkim',
  '12': 'Arunachal Pradesh',
  '13': 'Nagaland',
  '14': 'Manipur',
  '15': 'Mizoram',
  '16': 'Tripura',
  '17': 'Meghalaya',
  '18': 'Assam',
  '19': 'West Bengal',
  '20': 'Jharkhand',
  '21': 'Odisha',
  '22': 'Chhattisgarh',
  '23': 'Madhya Pradesh',
  '24': 'Gujarat',
  '25': 'Daman and Diu',
  '26': 'Dadra and Nagar Haveli',
  '27': 'Maharashtra',
  '28': 'Andhra Pradesh',
  '29': 'Karnataka',
  '30': 'Goa',
  '31': 'Lakshadweep',
  '32': 'Kerala',
  '33': 'Tamil Nadu',
  '34': 'Puducherry',
  '35': 'Andaman and Nicobar Islands',
  '36': 'Telangana',
  '37': 'Andhra Pradesh (New)',
  '38': 'Ladakh'
};

// Common GST rates
export const GST_RATES = [0, 5, 12, 18, 28];

// Calculate GST amounts based on amount and rate
export const calculateGST = (amount, gstRate, fromState, toState) => {
  const gstAmount = (amount * gstRate) / 100;
  
  // If same state or union territory, apply CGST + SGST
  // If different states, apply IGST
  const isInterState = fromState !== toState;
  
  if (isInterState) {
    return {
      cgst: 0,
      sgst: 0,
      igst: gstAmount,
      total: gstAmount
    };
  } else {
    return {
      cgst: gstAmount / 2,
      sgst: gstAmount / 2,
      igst: 0,
      total: gstAmount
    };
  }
};

// Calculate price including GST
export const calculatePriceWithGST = (basePrice, gstRate) => {
  const gstAmount = (basePrice * gstRate) / 100;
  return basePrice + gstAmount;
};

// Calculate price excluding GST
export const calculatePriceExcludingGST = (priceWithGST, gstRate) => {
  return priceWithGST / (1 + gstRate / 100);
};

// Validate GSTIN format
export const validateGSTIN = (gstin) => {
  if (!gstin) return false;
  
  // GSTIN format: 15 characters
  // First 2: State code
  // Next 10: PAN of the entity
  // 13th: Number of registrations within a state for the same PAN
  // 14th: Z (default)
  // 15th: Check digit
  
  const gstinRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
  return gstinRegex.test(gstin);
};

// Extract state code from GSTIN
export const getStateCodeFromGSTIN = (gstin) => {
  if (!gstin || gstin.length < 2) return null;
  return gstin.substring(0, 2);
};

// Get state name from state code
export const getStateName = (stateCode) => {
  return STATE_CODES[stateCode] || 'Unknown State';
};

// HSN code suggestions for feed business
export const HSN_CODES = [
  { code: '2309', description: 'Fish/Shrimp Feed and Feed Supplements' },
  { code: '23091000', description: 'Dog or cat food, put up for retail sale' },
  { code: '23099010', description: 'Aquatic feed including shrimp feed, fish feed, prawn feed' },
  { code: '23099020', description: 'Poultry feed' },
  { code: '23099030', description: 'Cattle feed' },
  { code: '23099090', description: 'Other animal feeds' },
  { code: '3824', description: 'Feed additives and supplements' },
  { code: '38249990', description: 'Other feed additives' }
];

// Get HSN suggestions based on search term
export const getHSNSuggestions = (searchTerm) => {
  if (!searchTerm) return HSN_CODES.slice(0, 5);
  
  const term = searchTerm.toLowerCase();
  return HSN_CODES.filter(hsn => 
    hsn.code.includes(term) || 
    hsn.description.toLowerCase().includes(term)
  );
};

// Format currency with Indian Rupee symbol
export const formatCurrency = (amount, showSymbol = true) => {
  const formatted = parseFloat(amount || 0).toFixed(2);
  return showSymbol ? `₹${formatted}` : formatted;
};

// Parse currency string to number
export const parseCurrency = (currencyString) => {
  if (typeof currencyString === 'number') return currencyString;
  return parseFloat(currencyString.replace(/[₹,]/g, '') || 0);
};

// Format numbers with Indian numbering system (lakhs, crores)
export const formatIndianNumber = (number) => {
  const num = parseFloat(number || 0);
  return num.toLocaleString('en-IN');
};

// Calculate invoice totals with GST
export const calculateInvoiceTotal = (items, fromState, toState) => {
  let subtotal = 0;
  let totalCGST = 0;
  let totalSGST = 0;
  let totalIGST = 0;
  
  items.forEach(item => {
    const itemTotal = item.quantity * item.unit_price;
    subtotal += itemTotal;
    
    const gst = calculateGST(itemTotal, item.gst_rate || 0, fromState, toState);
    totalCGST += gst.cgst;
    totalSGST += gst.sgst;
    totalIGST += gst.igst;
  });
  
  const totalGST = totalCGST + totalSGST + totalIGST;
  const grandTotal = subtotal + totalGST;
  
  return {
    subtotal,
    cgst: totalCGST,
    sgst: totalSGST,
    igst: totalIGST,
    totalGST,
    grandTotal
  };
};
