// Unit of measurement utilities for inventory management

// Common units used in feed business
export const UNITS = [
  { value: 'kg', label: 'Kilogram (kg)', category: 'weight' },
  { value: 'g', label: 'Gram (g)', category: 'weight' },
  { value: 'ton', label: 'Ton', category: 'weight' },
  { value: 'quintal', label: 'Quintal', category: 'weight' },
  { value: 'bag', label: 'Bag', category: 'packaging' },
  { value: 'sack', label: 'Sack', category: 'packaging' },
  { value: 'packet', label: 'Packet', category: 'packaging' },
  { value: 'box', label: 'Box', category: 'packaging' },
  { value: 'piece', label: 'Piece', category: 'count' },
  { value: 'dozen', label: 'Dozen', category: 'count' },
  { value: 'liter', label: 'Liter (L)', category: 'volume' },
  { value: 'ml', label: 'Milliliter (ml)', category: 'volume' }
];

// Get unit label by value
export const getUnitLabel = (unitValue) => {
  const unit = UNITS.find(u => u.value === unitValue);
  return unit ? unit.label : unitValue;
};

// Get units by category
export const getUnitsByCategory = (category) => {
  return UNITS.filter(unit => unit.category === category);
};

// Weight conversion utilities
export const convertWeight = (value, fromUnit, toUnit) => {
  const weightConversions = {
    'g': 1,
    'kg': 1000,
    'quintal': 100000,
    'ton': 1000000
  };
  
  if (!weightConversions[fromUnit] || !weightConversions[toUnit]) {
    return value; // Return original value if conversion not supported
  }
  
  // Convert to grams first, then to target unit
  const valueInGrams = value * weightConversions[fromUnit];
  return valueInGrams / weightConversions[toUnit];
};

// Volume conversion utilities
export const convertVolume = (value, fromUnit, toUnit) => {
  const volumeConversions = {
    'ml': 1,
    'liter': 1000
  };
  
  if (!volumeConversions[fromUnit] || !volumeConversions[toUnit]) {
    return value;
  }
  
  // Convert to ml first, then to target unit
  const valueInMl = value * volumeConversions[fromUnit];
  return valueInMl / volumeConversions[toUnit];
};

// Format quantity with unit
export const formatQuantity = (quantity, unit) => {
  const formattedQty = parseFloat(quantity || 0).toFixed(2);
  const unitLabel = getUnitLabel(unit);
  return `${formattedQty} ${unitLabel}`;
};

// Parse quantity string
export const parseQuantity = (quantityString) => {
  if (typeof quantityString === 'number') return quantityString;
  return parseFloat(quantityString.replace(/[^0-9.-]/g, '') || 0);
};

// Standard packaging sizes for feed business
export const STANDARD_PACKAGES = {
  'fish_feed': [
    { size: 1, unit: 'kg', description: '1 kg packet' },
    { size: 5, unit: 'kg', description: '5 kg bag' },
    { size: 10, unit: 'kg', description: '10 kg bag' },
    { size: 25, unit: 'kg', description: '25 kg sack' },
    { size: 50, unit: 'kg', description: '50 kg sack' }
  ],
  'shrimp_feed': [
    { size: 0.5, unit: 'kg', description: '500g packet' },
    { size: 1, unit: 'kg', description: '1 kg packet' },
    { size: 5, unit: 'kg', description: '5 kg bag' },
    { size: 15, unit: 'kg', description: '15 kg bag' },
    { size: 25, unit: 'kg', description: '25 kg sack' }
  ],
  'supplements': [
    { size: 100, unit: 'g', description: '100g bottle' },
    { size: 250, unit: 'g', description: '250g bottle' },
    { size: 500, unit: 'g', description: '500g bottle' },
    { size: 1, unit: 'kg', description: '1 kg container' },
    { size: 5, unit: 'kg', description: '5 kg container' }
  ]
};

// Get standard packages for a category
export const getStandardPackages = (category) => {
  const categoryKey = category.toLowerCase().replace(/\s+/g, '_');
  return STANDARD_PACKAGES[categoryKey] || STANDARD_PACKAGES['fish_feed'];
};

// Calculate bulk pricing based on quantity
export const calculateBulkPrice = (basePrice, quantity, unit) => {
  let discountPercentage = 0;
  
  // Apply bulk discounts based on quantity (example rules)
  if (unit === 'kg') {
    if (quantity >= 1000) discountPercentage = 15; // 15% for 1000kg+
    else if (quantity >= 500) discountPercentage = 10; // 10% for 500kg+
    else if (quantity >= 100) discountPercentage = 5;  // 5% for 100kg+
  } else if (unit === 'bag' || unit === 'sack') {
    if (quantity >= 100) discountPercentage = 12; // 12% for 100+ bags
    else if (quantity >= 50) discountPercentage = 8;  // 8% for 50+ bags
    else if (quantity >= 20) discountPercentage = 5;  // 5% for 20+ bags
  }
  
  const discountAmount = (basePrice * discountPercentage) / 100;
  return {
    originalPrice: basePrice,
    discountPercentage,
    discountAmount,
    finalPrice: basePrice - discountAmount
  };
};

// Validate stock levels
export const validateStockLevel = (currentStock, minStockLevel, unit) => {
  const current = parseFloat(currentStock || 0);
  const minimum = parseFloat(minStockLevel || 0);
  
  return {
    isLowStock: current <= minimum,
    isOutOfStock: current <= 0,
    difference: current - minimum,
    status: current <= 0 ? 'out_of_stock' : 
            current <= minimum ? 'low_stock' : 'in_stock'
  };
};
