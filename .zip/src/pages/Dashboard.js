import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { formatCurrency } from '../utils/gst';

const Dashboard = () => {
  const { getAllRecords, loading } = useDatabase();
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalCustomers: 0,
    totalSuppliers: 0,
    totalSales: 0,
    totalRevenue: 0,
    lowStockItems: 0
  });
  const [recentSales, setRecentSales] = useState([]);
  const [lowStockProducts, setLowStockProducts] = useState([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // Load statistics
      const [products, customers, suppliers, sales] = await Promise.all([
        getAllRecords('products'),
        getAllRecords('customers'),
        getAllRecords('suppliers'),
        getAllRecords('sales')
      ]);

      // Calculate stats
      const totalRevenue = sales.reduce((sum, sale) => sum + parseFloat(sale.total_amount || 0), 0);
      const lowStock = products.filter(product => 
        parseFloat(product.current_stock) <= parseFloat(product.min_stock_level)
      );

      setStats({
        totalProducts: products.length,
        totalCustomers: customers.length,
        totalSuppliers: suppliers.length,
        totalSales: sales.length,
        totalRevenue,
        lowStockItems: lowStock.length
      });

      // Recent sales (last 5)
      const recentSalesData = sales.slice(0, 5).map(sale => {
        const customer = customers.find(c => c.id === sale.customer_id);
        return {
          ...sale,
          customer_name: customer ? customer.name : 'Walk-in Customer'
        };
      });
      setRecentSales(recentSalesData);

      // Low stock products (first 10)
      setLowStockProducts(lowStock.slice(0, 10));

    } catch (error) {
      console.error('Error loading dashboard data:', error);
    }
  };

  if (loading) {
    return (
      <div className="text-center">
        <p>Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Dashboard</h1>
        <p className="page-subtitle">Overview of your inventory management system</p>
      </div>

      {/* Statistics Grid */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-number">{stats.totalProducts}</div>
          <div className="stat-label">Total Products</div>
        </div>
        <div className="stat-card">
          <div className="stat-number">{stats.totalCustomers}</div>
          <div className="stat-label">Total Customers</div>
        </div>
        <div className="stat-card">
          <div className="stat-number">{stats.totalSuppliers}</div>
          <div className="stat-label">Total Suppliers</div>
        </div>
        <div className="stat-card">
          <div className="stat-number">{stats.totalSales}</div>
          <div className="stat-label">Total Sales</div>
        </div>
        <div className="stat-card">
          <div className="stat-number">{formatCurrency(stats.totalRevenue)}</div>
          <div className="stat-label">Total Revenue</div>
        </div>
        <div className="stat-card">
          <div className="stat-number" style={{ color: stats.lowStockItems > 0 ? '#e74c3c' : '#27ae60' }}>
            {stats.lowStockItems}
          </div>
          <div className="stat-label">Low Stock Items</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* Recent Sales */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Recent Sales</h3>
          </div>
          {recentSales.length > 0 ? (
            <table className="table">
              <thead>
                <tr>
                  <th>Invoice</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                {recentSales.map(sale => (
                  <tr key={sale.id}>
                    <td>{sale.invoice_number}</td>
                    <td>{sale.customer_name}</td>
                    <td>{new Date(sale.sale_date).toLocaleDateString()}</td>
                    <td className="currency">{formatCurrency(sale.total_amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No recent sales found.</p>
          )}
        </div>

        {/* Low Stock Products */}
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Low Stock Alert</h3>
          </div>
          {lowStockProducts.length > 0 ? (
            <table className="table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Current Stock</th>
                  <th>Min Level</th>
                  <th>Unit</th>
                </tr>
              </thead>
              <tbody>
                {lowStockProducts.map(product => (
                  <tr key={product.id}>
                    <td>{product.name}</td>
                    <td style={{ color: parseFloat(product.current_stock) <= 0 ? '#e74c3c' : '#f39c12' }}>
                      {parseFloat(product.current_stock).toFixed(2)}
                    </td>
                    <td>{parseFloat(product.min_stock_level).toFixed(2)}</td>
                    <td>{product.unit}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="alert alert-success">
              <p>✅ All products are adequately stocked!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
