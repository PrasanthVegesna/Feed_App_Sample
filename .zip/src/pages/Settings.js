import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { STATE_CODES, validateGSTIN, GST_RATES } from '../utils/gst';

const Settings = () => {
  const { 
    getAllRecords, 
    updateRecord, 
    insertRecord, 
    loading, 
    settings, 
    setSettings,
    syncToMongoDB,
    restoreFromMongoDB,
    testMongoConnection
  } = useDatabase();
  
  const [formData, setFormData] = useState({
    company_name: '',
    company_address: '',
    company_phone: '',
    company_email: '',
    gstin: '',
    state_code: '27',
    default_gst_rate: '18',
    currency_symbol: '₹',
    mongodb_uri: '',
    mongodb_database: 'inventory_management'
  });
  const [message, setMessage] = useState('');
  const [mongoStatus, setMongoStatus] = useState('');
  const [activeTab, setActiveTab] = useState('company');

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const settingsData = await getAllRecords('settings');
      const settingsObj = {};
      settingsData.forEach(setting => {
        settingsObj[setting.key] = setting.value;
      });
      
      setFormData({
        company_name: settingsObj.company_name || '',
        company_address: settingsObj.company_address || '',
        company_phone: settingsObj.company_phone || '',
        company_email: settingsObj.company_email || '',
        gstin: settingsObj.gstin || '',
        state_code: settingsObj.state_code || '27',
        default_gst_rate: settingsObj.default_gst_rate || '18',
        currency_symbol: settingsObj.currency_symbol || '₹',
        mongodb_uri: settingsObj.mongodb_uri || '',
        mongodb_database: settingsObj.mongodb_database || 'inventory_management'
      });
      
      setSettings(settingsObj);
    } catch (error) {
      setMessage('Error loading settings: ' + error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate GSTIN if provided
    if (formData.gstin && !validateGSTIN(formData.gstin)) {
      setMessage('Invalid GSTIN format');
      return;
    }

    try {
      // Update or insert each setting
      for (const [key, value] of Object.entries(formData)) {
        const existingSetting = await getAllRecords('settings', 'key = ?', [key]);
        
        if (existingSetting.length > 0) {
          await updateRecord('settings', { value }, 'key = ?', [key]);
        } else {
          await insertRecord('settings', { key, value });
        }
      }
      
      setMessage('Settings saved successfully');
      setSettings(formData);
      
      // Update environment variables for MongoDB if changed
      if (formData.mongodb_uri) {
        process.env.MONGODB_URI = formData.mongodb_uri;
        process.env.MONGODB_DATABASE = formData.mongodb_database;
      }
      
    } catch (error) {
      setMessage('Error saving settings: ' + error.message);
    }
  };

  const handleMongoTest = async () => {
    setMongoStatus('Testing connection...');
    try {
      // Temporarily set environment variables
      const originalUri = process.env.MONGODB_URI;
      const originalDb = process.env.MONGODB_DATABASE;
      
      process.env.MONGODB_URI = formData.mongodb_uri;
      process.env.MONGODB_DATABASE = formData.mongodb_database;
      
      const result = await testMongoConnection();
      
      if (result.success) {
        setMongoStatus('✅ Connection successful');
      } else {
        setMongoStatus('❌ Connection failed: ' + result.message);
      }
      
      // Restore original environment variables if test failed
      if (!result.success) {
        process.env.MONGODB_URI = originalUri;
        process.env.MONGODB_DATABASE = originalDb;
      }
    } catch (error) {
      setMongoStatus('❌ Connection error: ' + error.message);
    }
  };

  const handleSync = async () => {
    setMessage('Syncing data to MongoDB...');
    try {
      const result = await syncToMongoDB();
      if (result.success) {
        setMessage(`✅ Data synced successfully at ${new Date(result.timestamp).toLocaleString()}`);
      } else {
        setMessage('❌ Sync failed: ' + result.message);
      }
    } catch (error) {
      setMessage('❌ Sync error: ' + error.message);
    }
  };

  const handleRestore = async () => {
    if (!window.confirm('This will replace all local data with data from MongoDB. Are you sure?')) {
      return;
    }
    
    setMessage('Restoring data from MongoDB...');
    try {
      const result = await restoreFromMongoDB();
      if (result.success) {
        setMessage(`✅ Data restored successfully from ${new Date(result.timestamp).toLocaleString()}`);
        // Reload the page to refresh all data
        window.location.reload();
      } else {
        setMessage('❌ Restore failed: ' + result.message);
      }
    } catch (error) {
      setMessage('❌ Restore error: ' + error.message);
    }
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Settings</h1>
        <p className="page-subtitle">Configure application settings and preferences</p>
      </div>

      {message && (
        <div className={`alert ${message.includes('Error') || message.includes('❌') ? 'alert-error' : 'alert-success'}`}>
          {message}
        </div>
      )}

      {/* Tab Navigation */}
      <div className="card">
        <div style={{ borderBottom: '1px solid #ddd', padding: '0 20px' }}>
          <div style={{ display: 'flex', gap: '0' }}>
            <button
              className={`btn ${activeTab === 'company' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setActiveTab('company')}
              style={{ borderRadius: '5px 5px 0 0', margin: '0' }}
            >
              Company Info
            </button>
            <button
              className={`btn ${activeTab === 'tax' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setActiveTab('tax')}
              style={{ borderRadius: '5px 5px 0 0', margin: '0' }}
            >
              Tax Settings
            </button>
            <button
              className={`btn ${activeTab === 'backup' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setActiveTab('backup')}
              style={{ borderRadius: '5px 5px 0 0', margin: '0' }}
            >
              Backup & Sync
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Company Information Tab */}
          {activeTab === 'company' && (
            <div style={{ padding: '20px' }}>
              <h4>Company Information</h4>
              
              <div className="form-group">
                <label className="form-label">Company Name</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.company_name}
                  onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                  placeholder="Your Fish Feed Company"
                />
              </div>

              <div className="form-group">
                <label className="form-label">Company Address</label>
                <textarea
                  className="form-control"
                  rows="3"
                  value={formData.company_address}
                  onChange={(e) => setFormData({ ...formData, company_address: e.target.value })}
                  placeholder="Complete business address"
                />
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Phone Number</label>
                    <input
                      type="tel"
                      className="form-control"
                      value={formData.company_phone}
                      onChange={(e) => setFormData({ ...formData, company_phone: e.target.value })}
                      placeholder="+91 9876543210"
                    />
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Email Address</label>
                    <input
                      type="email"
                      className="form-control"
                      value={formData.company_email}
                      onChange={(e) => setFormData({ ...formData, company_email: e.target.value })}
                      placeholder="business@company.com"
                    />
                  </div>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Currency Symbol</label>
                <select
                  className="form-control"
                  value={formData.currency_symbol}
                  onChange={(e) => setFormData({ ...formData, currency_symbol: e.target.value })}
                >
                  <option value="₹">₹ (Indian Rupee)</option>
                  <option value="$">$ (US Dollar)</option>
                  <option value="€">€ (Euro)</option>
                  <option value="£">£ (British Pound)</option>
                </select>
              </div>
            </div>
          )}

          {/* Tax Settings Tab */}
          {activeTab === 'tax' && (
            <div style={{ padding: '20px' }}>
              <h4>Tax & GST Settings</h4>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">GSTIN</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.gstin}
                      onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                      placeholder="15-digit GSTIN"
                      maxLength="15"
                      style={{ fontFamily: 'monospace' }}
                    />
                    {formData.gstin && !validateGSTIN(formData.gstin) && (
                      <div style={{ color: '#e74c3c', fontSize: '0.8em', marginTop: '5px' }}>
                        Invalid GSTIN format
                      </div>
                    )}
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">State Code</label>
                    <select
                      className="form-control"
                      value={formData.state_code}
                      onChange={(e) => setFormData({ ...formData, state_code: e.target.value })}
                    >
                      {Object.entries(STATE_CODES).map(([code, name]) => (
                        <option key={code} value={code}>
                          {code} - {name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Default GST Rate (%)</label>
                <select
                  className="form-control"
                  value={formData.default_gst_rate}
                  onChange={(e) => setFormData({ ...formData, default_gst_rate: e.target.value })}
                >
                  {GST_RATES.map(rate => (
                    <option key={rate} value={rate}>{rate}%</option>
                  ))}
                </select>
                <div style={{ fontSize: '0.8em', color: '#666', marginTop: '5px' }}>
                  This will be the default GST rate for new products
                </div>
              </div>

              <div className="alert alert-warning">
                <strong>Note:</strong> Make sure your GSTIN and state code are correct as they affect GST calculations (CGST/SGST vs IGST).
              </div>
            </div>
          )}

          {/* Backup & Sync Tab */}
          {activeTab === 'backup' && (
            <div style={{ padding: '20px' }}>
              <h4>MongoDB Atlas Backup & Sync</h4>

              <div className="form-group">
                <label className="form-label">MongoDB Connection URI</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.mongodb_uri}
                  onChange={(e) => setFormData({ ...formData, mongodb_uri: e.target.value })}
                  placeholder="mongodb+srv://username:password@cluster.mongodb.net/"
                  style={{ fontFamily: 'monospace' }}
                />
                <div style={{ fontSize: '0.8em', color: '#666', marginTop: '5px' }}>
                  Get this from your MongoDB Atlas dashboard
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Database Name</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.mongodb_database}
                  onChange={(e) => setFormData({ ...formData, mongodb_database: e.target.value })}
                  placeholder="inventory_management"
                />
              </div>

              {mongoStatus && (
                <div className="alert alert-warning">
                  {mongoStatus}
                </div>
              )}

              <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={handleMongoTest}
                  disabled={loading || !formData.mongodb_uri}
                >
                  Test Connection
                </button>
                <button 
                  type="button" 
                  className="btn btn-success"
                  onClick={handleSync}
                  disabled={loading || !formData.mongodb_uri}
                >
                  Sync to Cloud
                </button>
                <button 
                  type="button" 
                  className="btn btn-warning"
                  onClick={handleRestore}
                  disabled={loading || !formData.mongodb_uri}
                >
                  Restore from Cloud
                </button>
              </div>

              <div className="alert alert-warning">
                <strong>Important:</strong>
                <ul style={{ margin: '10px 0', paddingLeft: '20px' }}>
                  <li>Always test the connection before syncing</li>
                  <li>Sync regularly to backup your data to the cloud</li>
                  <li>Restore will replace ALL local data with cloud data</li>
                  <li>Keep your MongoDB credentials secure</li>
                </ul>
              </div>
            </div>
          )}

          <div style={{ padding: '0 20px 20px 20px', borderTop: '1px solid #ddd' }}>
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={loading}
              style={{ marginTop: '20px' }}
            >
              Save Settings
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Settings;
