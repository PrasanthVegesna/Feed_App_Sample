import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { v4 as uuidv4 } from 'uuid';

const Categories = () => {
  const { getAllRecords, insertRecord, updateRecord, deleteRecord, loading } = useDatabase();
  const [categories, setCategories] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: ''
  });
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      const data = await getAllRecords('categories');
      setCategories(data);
    } catch (error) {
      setMessage('Error loading categories: ' + error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      setMessage('Category name is required');
      return;
    }

    try {
      if (editingCategory) {
        await updateRecord('categories', formData, 'id = ?', [editingCategory.id]);
        setMessage('Category updated successfully');
      } else {
        const categoryData = {
          id: uuidv4(),
          ...formData
        };
        await insertRecord('categories', categoryData);
        setMessage('Category added successfully');
      }
      
      resetForm();
      loadCategories();
    } catch (error) {
      setMessage('Error saving category: ' + error.message);
    }
  };

  const handleEdit = (category) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      description: category.description || ''
    });
    setShowModal(true);
  };

  const handleDelete = async (categoryId) => {
    if (!window.confirm('Are you sure you want to delete this category?')) {
      return;
    }

    try {
      // Check if category is being used by products
      const products = await getAllRecords('products', 'category_id = ?', [categoryId]);
      
      if (products.length > 0) {
        setMessage(`Cannot delete category. It is being used by ${products.length} product(s).`);
        return;
      }

      await deleteRecord('categories', 'id = ?', [categoryId]);
      setMessage('Category deleted successfully');
      loadCategories();
    } catch (error) {
      setMessage('Error deleting category: ' + error.message);
    }
  };

  const resetForm = () => {
    setFormData({ name: '', description: '' });
    setEditingCategory(null);
    setShowModal(false);
    setMessage('');
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Categories</h1>
        <p className="page-subtitle">Manage product categories</p>
      </div>

      {message && (
        <div className={`alert ${message.includes('Error') || message.includes('Cannot') ? 'alert-error' : 'alert-success'}`}>
          {message}
        </div>
      )}

      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Product Categories</h3>
          <button 
            className="btn btn-primary"
            onClick={() => setShowModal(true)}
            disabled={loading}
          >
            Add Category
          </button>
        </div>

        {categories.length > 0 ? (
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Created Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {categories.map(category => (
                <tr key={category.id}>
                  <td><strong>{category.name}</strong></td>
                  <td>{category.description || '-'}</td>
                  <td>{new Date(category.created_at).toLocaleDateString()}</td>
                  <td>
                    <div className="table-actions">
                      <button 
                        className="btn btn-sm btn-warning"
                        onClick={() => handleEdit(category)}
                        disabled={loading}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn-sm btn-danger"
                        onClick={() => handleDelete(category.id)}
                        disabled={loading}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No categories found. Click "Add Category" to create your first category.</p>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3 className="modal-title">
                {editingCategory ? 'Edit Category' : 'Add New Category'}
              </h3>
              <button className="close-btn" onClick={resetForm}>×</button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Category Name *</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Description</label>
                <textarea
                  className="form-control"
                  rows="3"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Optional description for this category"
                />
              </div>

              <div className="form-group text-right">
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={resetForm}
                  style={{ marginRight: '10px' }}
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  disabled={loading}
                >
                  {editingCategory ? 'Update' : 'Add'} Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Categories;
