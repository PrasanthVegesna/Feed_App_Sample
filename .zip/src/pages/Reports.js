import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { formatCurrency } from '../utils/gst';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

const Reports = () => {
  const { getAllRecords, loading } = useDatabase();
  const [reportType, setReportType] = useState('sales');
  const [dateRange, setDateRange] = useState({
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days ago
    endDate: new Date().toISOString().split('T')[0]
  });
  const [reportData, setReportData] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    generateReport();
  }, [reportType, dateRange]);

  const generateReport = async () => {
    try {
      setMessage('Generating report...');
      
      switch (reportType) {
        case 'sales':
          await generateSalesReport();
          break;
        case 'inventory':
          await generateInventoryReport();
          break;
        case 'purchases':
          await generatePurchasesReport();
          break;
        case 'gst':
          await generateGSTReport();
          break;
        default:
          setMessage('Unknown report type');
      }
    } catch (error) {
      setMessage('Error generating report: ' + error.message);
    }
  };

  const generateSalesReport = async () => {
    const sales = await getAllRecords('sales');
    const customers = await getAllRecords('customers');
    const saleItems = await getAllRecords('sale_items');
    const products = await getAllRecords('products');

    // Filter sales by date range
    const filteredSales = sales.filter(sale => {
      const saleDate = new Date(sale.sale_date);
      const start = new Date(dateRange.startDate);
      const end = new Date(dateRange.endDate);
      return saleDate >= start && saleDate <= end;
    });

    const totalSales = filteredSales.length;
    const totalRevenue = filteredSales.reduce((sum, sale) => sum + parseFloat(sale.total_amount || 0), 0);
    const totalGST = filteredSales.reduce((sum, sale) => 
      sum + parseFloat(sale.cgst_amount || 0) + parseFloat(sale.sgst_amount || 0) + parseFloat(sale.igst_amount || 0), 0
    );

    // Top products
    const productSales = {};
    filteredSales.forEach(sale => {
      const items = saleItems.filter(item => item.sale_id === sale.id);
      items.forEach(item => {
        if (!productSales[item.product_id]) {
          productSales[item.product_id] = { quantity: 0, revenue: 0 };
        }
        productSales[item.product_id].quantity += parseFloat(item.quantity);
        productSales[item.product_id].revenue += parseFloat(item.total_amount);
      });
    });

    const topProducts = Object.entries(productSales)
      .map(([productId, data]) => ({
        product: products.find(p => p.id === productId)?.name || 'Unknown',
        ...data
      }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    // Payment status breakdown
    const paymentStatus = {
      paid: filteredSales.filter(s => s.payment_status === 'paid').length,
      pending: filteredSales.filter(s => s.payment_status === 'pending').length,
      partial: filteredSales.filter(s => s.payment_status === 'partial').length,
      overdue: filteredSales.filter(s => s.payment_status === 'overdue').length
    };

    setReportData({
      type: 'sales',
      summary: { totalSales, totalRevenue, totalGST },
      topProducts,
      paymentStatus,
      details: filteredSales.map(sale => ({
        ...sale,
        customer_name: customers.find(c => c.id === sale.customer_id)?.name || 'Walk-in Customer'
      }))
    });
    setMessage('');
  };

  const generateInventoryReport = async () => {
    const products = await getAllRecords('products');
    const categories = await getAllRecords('categories');

    const totalProducts = products.length;
    const totalValue = products.reduce((sum, product) => 
      sum + (parseFloat(product.current_stock) * parseFloat(product.purchase_price)), 0
    );

    const lowStockItems = products.filter(product => 
      parseFloat(product.current_stock) <= parseFloat(product.min_stock_level)
    );

    const outOfStockItems = products.filter(product => 
      parseFloat(product.current_stock) <= 0
    );

    // Category-wise breakdown
    const categoryBreakdown = {};
    products.forEach(product => {
      const categoryName = categories.find(c => c.id === product.category_id)?.name || 'Uncategorized';
      if (!categoryBreakdown[categoryName]) {
        categoryBreakdown[categoryName] = { count: 0, value: 0 };
      }
      categoryBreakdown[categoryName].count++;
      categoryBreakdown[categoryName].value += parseFloat(product.current_stock) * parseFloat(product.purchase_price);
    });

    setReportData({
      type: 'inventory',
      summary: { 
        totalProducts, 
        totalValue, 
        lowStockCount: lowStockItems.length,
        outOfStockCount: outOfStockItems.length
      },
      lowStockItems,
      outOfStockItems,
      categoryBreakdown,
      allProducts: products.map(product => ({
        ...product,
        category_name: categories.find(c => c.id === product.category_id)?.name || 'Uncategorized',
        stock_value: parseFloat(product.current_stock) * parseFloat(product.purchase_price)
      }))
    });
    setMessage('');
  };

  const generatePurchasesReport = async () => {
    const purchases = await getAllRecords('purchases');
    const suppliers = await getAllRecords('suppliers');

    // Filter purchases by date range
    const filteredPurchases = purchases.filter(purchase => {
      const purchaseDate = new Date(purchase.purchase_date);
      const start = new Date(dateRange.startDate);
      const end = new Date(dateRange.endDate);
      return purchaseDate >= start && purchaseDate <= end;
    });

    const totalPurchases = filteredPurchases.length;
    const totalAmount = filteredPurchases.reduce((sum, purchase) => sum + parseFloat(purchase.total_amount || 0), 0);

    // Supplier-wise breakdown
    const supplierBreakdown = {};
    filteredPurchases.forEach(purchase => {
      const supplierName = suppliers.find(s => s.id === purchase.supplier_id)?.name || 'Direct Purchase';
      if (!supplierBreakdown[supplierName]) {
        supplierBreakdown[supplierName] = { count: 0, amount: 0 };
      }
      supplierBreakdown[supplierName].count++;
      supplierBreakdown[supplierName].amount += parseFloat(purchase.total_amount);
    });

    // Payment status breakdown
    const paymentStatus = {
      paid: filteredPurchases.filter(p => p.payment_status === 'paid').length,
      pending: filteredPurchases.filter(p => p.payment_status === 'pending').length,
      partial: filteredPurchases.filter(p => p.payment_status === 'partial').length,
      overdue: filteredPurchases.filter(p => p.payment_status === 'overdue').length
    };

    setReportData({
      type: 'purchases',
      summary: { totalPurchases, totalAmount },
      supplierBreakdown,
      paymentStatus,
      details: filteredPurchases.map(purchase => ({
        ...purchase,
        supplier_name: suppliers.find(s => s.id === purchase.supplier_id)?.name || 'Direct Purchase'
      }))
    });
    setMessage('');
  };

  const generateGSTReport = async () => {
    const sales = await getAllRecords('sales');
    
    // Filter sales by date range
    const filteredSales = sales.filter(sale => {
      const saleDate = new Date(sale.sale_date);
      const start = new Date(dateRange.startDate);
      const end = new Date(dateRange.endDate);
      return saleDate >= start && saleDate <= end;
    });

    const totalCGST = filteredSales.reduce((sum, sale) => sum + parseFloat(sale.cgst_amount || 0), 0);
    const totalSGST = filteredSales.reduce((sum, sale) => sum + parseFloat(sale.sgst_amount || 0), 0);
    const totalIGST = filteredSales.reduce((sum, sale) => sum + parseFloat(sale.igst_amount || 0), 0);
    const totalGST = totalCGST + totalSGST + totalIGST;
    const totalTaxableValue = filteredSales.reduce((sum, sale) => sum + parseFloat(sale.subtotal || 0), 0);

    setReportData({
      type: 'gst',
      summary: { 
        totalCGST, 
        totalSGST, 
        totalIGST, 
        totalGST,
        totalTaxableValue,
        totalTransactions: filteredSales.length
      },
      transactions: filteredSales
    });
    setMessage('');
  };

  const exportToPDF = () => {
    if (!reportData) {
      setMessage('No report data to export');
      return;
    }

    try {
      const doc = new jsPDF();
      
      // Add title
      doc.setFontSize(20);
      doc.text(`${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report`, 20, 20);
      
      // Add date range
      doc.setFontSize(12);
      doc.text(`Period: ${dateRange.startDate} to ${dateRange.endDate}`, 20, 35);
      
      let yPosition = 50;

      if (reportType === 'sales' && reportData.details) {
        // Sales summary
        doc.text('Sales Summary:', 20, yPosition);
        yPosition += 10;
        doc.text(`Total Sales: ${formatCurrency(reportData.summary.totalRevenue)}`, 20, yPosition);
        yPosition += 10;
        doc.text(`Total Transactions: ${reportData.summary.totalSales}`, 20, yPosition);
        yPosition += 20;

        // Sales table
        if (reportData.details.length > 0) {
          const tableData = reportData.details.map(sale => [
            sale.invoice_number,
            sale.customer_name || 'Walk-in',
            new Date(sale.sale_date).toLocaleDateString(),
            formatCurrency(sale.total_amount),
            sale.payment_status
          ]);

          doc.autoTable({
            head: [['Invoice', 'Customer', 'Date', 'Amount', 'Status']],
            body: tableData,
            startY: yPosition,
            theme: 'grid'
          });
        }
      } else if (reportType === 'inventory' && reportData.allProducts) {
        // Inventory table
        const tableData = reportData.allProducts.map(item => [
          item.name,
          item.category_name || 'Uncategorized',
          `${item.current_stock} ${item.unit}`,
          `${item.min_stock_level} ${item.unit}`,
          item.current_stock < item.min_stock_level ? 'Low Stock' : 'OK'
        ]);

        doc.autoTable({
          head: [['Product', 'Category', 'Stock', 'Min Level', 'Status']],
          body: tableData,
          startY: yPosition,
          theme: 'grid'
        });
      } else if (reportType === 'purchases' && reportData.details) {
        // Purchases table
        const tableData = reportData.details.map(purchase => [
          purchase.invoice_number || 'N/A',
          purchase.supplier_name || 'Direct',
          new Date(purchase.purchase_date).toLocaleDateString(),
          formatCurrency(purchase.total_amount),
          purchase.payment_status
        ]);

        doc.autoTable({
          head: [['Invoice', 'Supplier', 'Date', 'Amount', 'Status']],
          body: tableData,
          startY: yPosition,
          theme: 'grid'
        });
      } else if (reportType === 'gst' && reportData.transactions) {
        // GST table
        const tableData = reportData.transactions.map(transaction => [
          new Date(transaction.sale_date).toLocaleDateString(),
          transaction.invoice_number || 'N/A',
          formatCurrency(transaction.subtotal || 0),
          formatCurrency(transaction.cgst_amount || 0),
          formatCurrency(transaction.sgst_amount || 0),
          formatCurrency(transaction.igst_amount || 0),
          formatCurrency(transaction.total_amount || 0)
        ]);

        doc.autoTable({
          head: [['Date', 'Invoice', 'Taxable Value', 'CGST', 'SGST', 'IGST', 'Total']],
          body: tableData,
          startY: yPosition,
          theme: 'grid'
        });
      }

      doc.save(`${reportType}-report-${new Date().toISOString().split('T')[0]}.pdf`);
      setMessage('PDF exported successfully');
    } catch (error) {
      setMessage('Error exporting PDF: ' + error.message);
    }
  };

  const exportToExcel = () => {
    if (!reportData) {
      setMessage('No report data to export');
      return;
    }

    try {
      let worksheetData = [];
      let filename = `${reportType}-report-${new Date().toISOString().split('T')[0]}.xlsx`;

      if (reportType === 'sales' && reportData.details) {
        worksheetData = [
          ['Invoice Number', 'Customer', 'Date', 'Amount', 'Payment Status'],
          ...reportData.details.map(sale => [
            sale.invoice_number,
            sale.customer_name || 'Walk-in',
            new Date(sale.sale_date).toLocaleDateString(),
            sale.total_amount,
            sale.payment_status
          ])
        ];
      } else if (reportType === 'inventory' && reportData.allProducts) {
        worksheetData = [
          ['Product Name', 'Category', 'Current Stock', 'Unit', 'Min Level', 'Status'],
          ...reportData.allProducts.map(item => [
            item.name,
            item.category_name || 'Uncategorized',
            item.current_stock,
            item.unit,
            item.min_stock_level,
            item.current_stock < item.min_stock_level ? 'Low Stock' : 'OK'
          ])
        ];
      } else if (reportType === 'purchases' && reportData.details) {
        worksheetData = [
          ['Invoice Number', 'Supplier', 'Date', 'Amount', 'Payment Status'],
          ...reportData.details.map(purchase => [
            purchase.invoice_number || 'N/A',
            purchase.supplier_name || 'Direct',
            new Date(purchase.purchase_date).toLocaleDateString(),
            purchase.total_amount,
            purchase.payment_status
          ])
        ];
      } else if (reportType === 'gst' && reportData.transactions) {
        worksheetData = [
          ['Date', 'Invoice Number', 'Taxable Value', 'CGST', 'SGST', 'IGST', 'Total Amount'],
          ...reportData.transactions.map(transaction => [
            new Date(transaction.sale_date).toLocaleDateString(),
            transaction.invoice_number || 'N/A',
            transaction.subtotal || 0,
            transaction.cgst_amount || 0,
            transaction.sgst_amount || 0,
            transaction.igst_amount || 0,
            transaction.total_amount || 0
          ])
        ];
      }

      const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, reportType.charAt(0).toUpperCase() + reportType.slice(1));
      
      XLSX.writeFile(workbook, filename);
      setMessage('Excel file exported successfully');
    } catch (error) {
      setMessage('Error exporting Excel: ' + error.message);
    }
  };

  const printReport = () => {
    if (!reportData) {
      setMessage('No report data to print');
      return;
    }

    // Create a new window for printing
    const printWindow = window.open('', '_blank', 'width=800,height=600,scrollbars=yes,resizable=yes');
    
    if (!printWindow) {
      setMessage('Please allow pop-ups to enable printing. Check your browser\'s popup settings.');
      return;
    }

    let printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            margin: 20px;
            color: #333;
          }
          .report-header {
            text-align: center;
            border-bottom: 2px solid #333;
            padding-bottom: 20px;
            margin-bottom: 30px;
          }
          .report-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
          }
          .report-period {
            font-size: 14px;
            color: #666;
          }
          .summary-section {
            margin-bottom: 30px;
          }
          .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
          }
          .summary-item {
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
          }
          .summary-value {
            font-size: 20px;
            font-weight: bold;
            color: #2c3e50;
          }
          .summary-label {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }
          th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
          }
          th {
            background-color: #f5f5f5;
            font-weight: bold;
          }
          .currency {
            text-align: right;
          }
          .low-stock {
            color: #e74c3c;
            font-weight: bold;
          }
          .out-of-stock {
            color: #c0392b;
            font-weight: bold;
          }
          @media print {
            body { margin: 0; }
            .no-print { display: none; }
          }
          .print-actions {
            text-align: center;
            margin: 20px 0;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
          }
          .print-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
          }
          .print-btn:hover {
            background: #0056b3;
          }
          .close-btn {
            background: #6c757d;
            color: white;
            border: none;
            padding: 10px 20px;
            margin: 0 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
          }
          .close-btn:hover {
            background: #545b62;
          }
        </style>
      </head>
      <body>
        <div class="print-actions no-print">
          <button class="print-btn" onclick="window.print()">🖨️ Print Report</button>
          <button class="close-btn" onclick="window.close()">✕ Close</button>
        </div>
        <div class="report-header">
          <div class="report-title">${reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report</div>
          <div class="report-period">Period: ${new Date(dateRange.startDate).toLocaleDateString()} to ${new Date(dateRange.endDate).toLocaleDateString()}</div>
        </div>
    `;

    if (reportData) {
      // Add summary section
      printContent += '<div class="summary-section"><h3>Summary</h3><div class="summary-grid">';
      
      if (reportData.type === 'sales') {
        printContent += `
          <div class="summary-item">
            <div class="summary-value">${reportData.summary.totalSales}</div>
            <div class="summary-label">Total Sales</div>
          </div>
          <div class="summary-item">
            <div class="summary-value">${formatCurrency(reportData.summary.totalRevenue)}</div>
            <div class="summary-label">Total Revenue</div>
          </div>
          <div class="summary-item">
            <div class="summary-value">${formatCurrency(reportData.summary.totalGST)}</div>
            <div class="summary-label">Total GST</div>
          </div>
        `;
      } else if (reportData.type === 'inventory') {
        printContent += `
          <div class="summary-item">
            <div class="summary-value">${reportData.summary.totalProducts}</div>
            <div class="summary-label">Total Products</div>
          </div>
          <div class="summary-item">
            <div class="summary-value">${formatCurrency(reportData.summary.totalValue)}</div>
            <div class="summary-label">Inventory Value</div>
          </div>
          <div class="summary-item">
            <div class="summary-value low-stock">${reportData.summary.lowStockCount}</div>
            <div class="summary-label">Low Stock Items</div>
          </div>
          <div class="summary-item">
            <div class="summary-value out-of-stock">${reportData.summary.outOfStockCount}</div>
            <div class="summary-label">Out of Stock</div>
          </div>
        `;
      } else if (reportData.type === 'purchases') {
        printContent += `
          <div class="summary-item">
            <div class="summary-value">${reportData.summary.totalPurchases}</div>
            <div class="summary-label">Total Purchases</div>
          </div>
          <div class="summary-item">
            <div class="summary-value">${formatCurrency(reportData.summary.totalAmount)}</div>
            <div class="summary-label">Total Amount</div>
          </div>
        `;
      } else if (reportData.type === 'gst') {
        printContent += `
          <div class="summary-item">
            <div class="summary-value">${formatCurrency(reportData.summary.totalTaxableValue)}</div>
            <div class="summary-label">Taxable Value</div>
          </div>
          <div class="summary-item">
            <div class="summary-value">${formatCurrency(reportData.summary.totalCGST)}</div>
            <div class="summary-label">Total CGST</div>
          </div>
          <div class="summary-item">
            <div class="summary-value">${formatCurrency(reportData.summary.totalSGST)}</div>
            <div class="summary-label">Total SGST</div>
          </div>
          <div class="summary-item">
            <div class="summary-value">${formatCurrency(reportData.summary.totalIGST)}</div>
            <div class="summary-label">Total IGST</div>
          </div>
        `;
      }
      
      printContent += '</div></div>';

      // Add detailed table
      if (reportData.type === 'sales' && reportData.details) {
        printContent += `
          <h3>Sales Details</h3>
          <table>
            <thead>
              <tr>
                <th>Invoice</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
        `;
        reportData.details.forEach(sale => {
          printContent += `
            <tr>
              <td>${sale.invoice_number}</td>
              <td>${sale.customer_name || 'Walk-in'}</td>
              <td>${sale.sale_date}</td>
              <td class="currency">${formatCurrency(sale.total_amount)}</td>
              <td>${sale.payment_status}</td>
            </tr>
          `;
        });
        printContent += '</tbody></table>';
      } else if (reportData.type === 'inventory' && reportData.allProducts) {
        printContent += `
          <h3>Inventory Details</h3>
          <table>
            <thead>
              <tr>
                <th>Product</th>
                <th>Category</th>
                <th>Current Stock</th>
                <th>Min Level</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
        `;
        reportData.allProducts.forEach(item => {
          const isLowStock = item.current_stock < item.min_stock_level;
          printContent += `
            <tr>
              <td>${item.name}</td>
              <td>${item.category_name || 'Uncategorized'}</td>
              <td class="${isLowStock ? 'low-stock' : ''}">${item.current_stock} ${item.unit}</td>
              <td>${item.min_stock_level} ${item.unit}</td>
              <td class="${isLowStock ? 'low-stock' : ''}">${isLowStock ? 'Low Stock' : 'OK'}</td>
            </tr>
          `;
        });
        printContent += '</tbody></table>';
      } else if (reportData.type === 'purchases' && reportData.details) {
        printContent += `
          <h3>Purchase Details</h3>
          <table>
            <thead>
              <tr>
                <th>Invoice</th>
                <th>Supplier</th>
                <th>Date</th>
                <th>Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
        `;
        reportData.details.forEach(purchase => {
          printContent += `
            <tr>
              <td>${purchase.invoice_number || 'N/A'}</td>
              <td>${purchase.supplier_name || 'Direct'}</td>
              <td>${new Date(purchase.purchase_date).toLocaleDateString()}</td>
              <td class="currency">${formatCurrency(purchase.total_amount)}</td>
              <td>${purchase.payment_status}</td>
            </tr>
          `;
        });
        printContent += '</tbody></table>';
      } else if (reportData.type === 'gst' && reportData.transactions) {
        printContent += `
          <h3>GST Details</h3>
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Invoice</th>
                <th>Taxable Value</th>
                <th>CGST</th>
                <th>SGST</th>
                <th>IGST</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
        `;
        reportData.transactions.forEach(transaction => {
          printContent += `
            <tr>
              <td>${new Date(transaction.sale_date).toLocaleDateString()}</td>
              <td>${transaction.invoice_number || 'N/A'}</td>
              <td class="currency">${formatCurrency(transaction.subtotal || 0)}</td>
              <td class="currency">${formatCurrency(transaction.cgst_amount || 0)}</td>
              <td class="currency">${formatCurrency(transaction.sgst_amount || 0)}</td>
              <td class="currency">${formatCurrency(transaction.igst_amount || 0)}</td>
              <td class="currency">${formatCurrency(transaction.total_amount || 0)}</td>
            </tr>
          `;
        });
        printContent += '</tbody></table>';
      }
    }

    printContent += `
        </body>
      </html>
    `;

    printWindow.document.write(printContent);
    printWindow.document.close();
    
    // Wait for content to load, then focus the window
    setTimeout(() => {
      printWindow.focus();
      setMessage('Print preview opened successfully');
    }, 100);
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Reports</h1>
        <p className="page-subtitle">Generate and analyze business reports</p>
      </div>

      {message && (
        <div className={`alert ${message.includes('Error') ? 'alert-error' : 'alert-warning'}`}>
          {message}
        </div>
      )}

      {/* Report Controls */}
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Report Configuration</h3>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button className="btn btn-secondary btn-sm" onClick={exportToPDF}>
              Export PDF
            </button>
            <button className="btn btn-secondary btn-sm" onClick={exportToExcel}>
              Export Excel
            </button>
            <button className="btn btn-secondary btn-sm" onClick={printReport}>
              Print
            </button>
          </div>
        </div>

        <div className="form-row">
          <div className="form-col">
            <div className="form-group">
              <label className="form-label">Report Type</label>
              <select
                className="form-control"
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
              >
                <option value="sales">Sales Report</option>
                <option value="inventory">Inventory Report</option>
                <option value="purchases">Purchases Report</option>
                <option value="gst">GST Report</option>
              </select>
            </div>
          </div>
          <div className="form-col">
            <div className="form-group">
              <label className="form-label">Start Date</label>
              <input
                type="date"
                className="form-control"
                value={dateRange.startDate}
                onChange={(e) => setDateRange({ ...dateRange, startDate: e.target.value })}
              />
            </div>
          </div>
          <div className="form-col">
            <div className="form-group">
              <label className="form-label">End Date</label>
              <input
                type="date"
                className="form-control"
                value={dateRange.endDate}
                onChange={(e) => setDateRange({ ...dateRange, endDate: e.target.value })}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Report Content */}
      {reportData && (
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">
              {reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report
            </h3>
            <div style={{ fontSize: '0.9em', color: '#666' }}>
              Period: {new Date(dateRange.startDate).toLocaleDateString()} to {new Date(dateRange.endDate).toLocaleDateString()}
            </div>
          </div>

          {/* Summary */}
          <div className="stats-grid">
            {reportData.type === 'sales' && (
              <>
                <div className="stat-card">
                  <div className="stat-number">{reportData.summary.totalSales}</div>
                  <div className="stat-label">Total Sales</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{formatCurrency(reportData.summary.totalRevenue)}</div>
                  <div className="stat-label">Total Revenue</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{formatCurrency(reportData.summary.totalGST)}</div>
                  <div className="stat-label">Total GST</div>
                </div>
              </>
            )}

            {reportData.type === 'inventory' && (
              <>
                <div className="stat-card">
                  <div className="stat-number">{reportData.summary.totalProducts}</div>
                  <div className="stat-label">Total Products</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{formatCurrency(reportData.summary.totalValue)}</div>
                  <div className="stat-label">Inventory Value</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number" style={{ color: '#e74c3c' }}>{reportData.summary.lowStockCount}</div>
                  <div className="stat-label">Low Stock Items</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number" style={{ color: '#c0392b' }}>{reportData.summary.outOfStockCount}</div>
                  <div className="stat-label">Out of Stock</div>
                </div>
              </>
            )}

            {reportData.type === 'purchases' && (
              <>
                <div className="stat-card">
                  <div className="stat-number">{reportData.summary.totalPurchases}</div>
                  <div className="stat-label">Total Purchases</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{formatCurrency(reportData.summary.totalAmount)}</div>
                  <div className="stat-label">Total Amount</div>
                </div>
              </>
            )}

            {reportData.type === 'gst' && (
              <>
                <div className="stat-card">
                  <div className="stat-number">{formatCurrency(reportData.summary.totalTaxableValue)}</div>
                  <div className="stat-label">Taxable Value</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{formatCurrency(reportData.summary.totalCGST)}</div>
                  <div className="stat-label">Total CGST</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{formatCurrency(reportData.summary.totalSGST)}</div>
                  <div className="stat-label">Total SGST</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{formatCurrency(reportData.summary.totalIGST)}</div>
                  <div className="stat-label">Total IGST</div>
                </div>
              </>
            )}
          </div>

          {/* Detailed Data */}
          {reportData.type === 'sales' && reportData.topProducts && (
            <div style={{ marginTop: '20px' }}>
              <h4>Top Selling Products</h4>
              <table className="table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Quantity Sold</th>
                    <th>Revenue</th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.topProducts.map((product, index) => (
                    <tr key={index}>
                      <td>{product.product}</td>
                      <td>{product.quantity.toFixed(2)}</td>
                      <td className="currency">{formatCurrency(product.revenue)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {reportData.type === 'inventory' && reportData.lowStockItems && (
            <div style={{ marginTop: '20px' }}>
              <h4>Low Stock Alert</h4>
              <table className="table">
                <thead>
                  <tr>
                    <th>Product</th>
                    <th>Current Stock</th>
                    <th>Min Level</th>
                    <th>Unit</th>
                    <th>Stock Value</th>
                  </tr>
                </thead>
                <tbody>
                  {reportData.lowStockItems.map((product) => (
                    <tr key={product.id}>
                      <td>{product.name}</td>
                      <td style={{ color: parseFloat(product.current_stock) <= 0 ? '#e74c3c' : '#f39c12' }}>
                        {parseFloat(product.current_stock).toFixed(2)}
                      </td>
                      <td>{parseFloat(product.min_stock_level).toFixed(2)}</td>
                      <td>{product.unit}</td>
                      <td className="currency">
                        {formatCurrency(parseFloat(product.current_stock) * parseFloat(product.purchase_price))}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Reports;
