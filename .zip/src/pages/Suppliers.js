import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { v4 as uuidv4 } from 'uuid';
import { STATE_CODES, validateGSTIN } from '../utils/gst';

const Suppliers = () => {
  const { getAllRecords, insertRecord, updateRecord, deleteRecord, loading } = useDatabase();
  const [suppliers, setSuppliers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    gstin: '',
    state_code: '27'
  });
  const [message, setMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadSuppliers();
  }, []);

  const loadSuppliers = async () => {
    try {
      const data = await getAllRecords('suppliers');
      setSuppliers(data);
    } catch (error) {
      setMessage('Error loading suppliers: ' + error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      setMessage('Supplier name is required');
      return;
    }

    // Validate GSTIN if provided
    if (formData.gstin && !validateGSTIN(formData.gstin)) {
      setMessage('Invalid GSTIN format');
      return;
    }

    try {
      if (editingSupplier) {
        await updateRecord('suppliers', formData, 'id = ?', [editingSupplier.id]);
        setMessage('Supplier updated successfully');
      } else {
        const supplierData = {
          id: uuidv4(),
          ...formData
        };
        await insertRecord('suppliers', supplierData);
        setMessage('Supplier added successfully');
      }
      
      resetForm();
      loadSuppliers();
    } catch (error) {
      setMessage('Error saving supplier: ' + error.message);
    }
  };

  const handleEdit = (supplier) => {
    setEditingSupplier(supplier);
    setFormData({
      name: supplier.name,
      phone: supplier.phone || '',
      email: supplier.email || '',
      address: supplier.address || '',
      gstin: supplier.gstin || '',
      state_code: supplier.state_code || '27'
    });
    setShowModal(true);
  };

  const handleDelete = async (supplierId) => {
    if (!window.confirm('Are you sure you want to delete this supplier?')) {
      return;
    }

    try {
      // Check if supplier has purchases
      const purchases = await getAllRecords('purchases', 'supplier_id = ?', [supplierId]);
      
      if (purchases.length > 0) {
        setMessage(`Cannot delete supplier. They have ${purchases.length} purchase(s) on record.`);
        return;
      }

      await deleteRecord('suppliers', 'id = ?', [supplierId]);
      setMessage('Supplier deleted successfully');
      loadSuppliers();
    } catch (error) {
      setMessage('Error deleting supplier: ' + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      phone: '',
      email: '',
      address: '',
      gstin: '',
      state_code: '27'
    });
    setEditingSupplier(null);
    setShowModal(false);
    setMessage('');
  };

  const getStateName = (stateCode) => {
    return STATE_CODES[stateCode] || 'Unknown State';
  };

  const filteredSuppliers = suppliers.filter(supplier =>
    supplier.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (supplier.phone && supplier.phone.includes(searchTerm)) ||
    (supplier.email && supplier.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Suppliers</h1>
        <p className="page-subtitle">Manage supplier information and contacts</p>
      </div>

      {message && (
        <div className={`alert ${message.includes('Error') || message.includes('Cannot') ? 'alert-error' : 'alert-success'}`}>
          {message}
        </div>
      )}

      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Supplier Directory</h3>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <input
              type="text"
              className="form-control"
              placeholder="Search suppliers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ width: '250px' }}
            />
            <button 
              className="btn btn-primary"
              onClick={() => setShowModal(true)}
              disabled={loading}
            >
              Add Supplier
            </button>
          </div>
        </div>

        {filteredSuppliers.length > 0 ? (
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Contact</th>
                <th>Location</th>
                <th>GSTIN</th>
                <th>Registration Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredSuppliers.map(supplier => (
                <tr key={supplier.id}>
                  <td>
                    <strong>{supplier.name}</strong>
                    {supplier.email && (
                      <div style={{ fontSize: '0.8em', color: '#666' }}>
                        {supplier.email}
                      </div>
                    )}
                  </td>
                  <td>
                    {supplier.phone || 'No phone'}
                  </td>
                  <td>
                    {supplier.address && (
                      <div style={{ fontSize: '0.9em' }}>
                        {supplier.address}
                      </div>
                    )}
                    <div style={{ fontSize: '0.8em', color: '#666' }}>
                      {getStateName(supplier.state_code)}
                    </div>
                  </td>
                  <td>
                    {supplier.gstin ? (
                      <div style={{ fontFamily: 'monospace', fontSize: '0.9em' }}>
                        {supplier.gstin}
                      </div>
                    ) : (
                      <span style={{ color: '#999' }}>Not provided</span>
                    )}
                  </td>
                  <td>{new Date(supplier.created_at).toLocaleDateString()}</td>
                  <td>
                    <div className="table-actions">
                      <button 
                        className="btn btn-sm btn-warning"
                        onClick={() => handleEdit(supplier)}
                        disabled={loading}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn-sm btn-danger"
                        onClick={() => handleDelete(supplier.id)}
                        disabled={loading}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No suppliers found. {searchTerm ? 'Try a different search term or ' : ''}Click "Add Supplier" to create your first supplier.</p>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3 className="modal-title">
                {editingSupplier ? 'Edit Supplier' : 'Add New Supplier'}
              </h3>
              <button className="close-btn" onClick={resetForm}>×</button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Supplier Name *</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Phone Number</label>
                    <input
                      type="tel"
                      className="form-control"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="e.g., +91 9876543210"
                    />
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Email Address</label>
                    <input
                      type="email"
                      className="form-control"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="supplier@example.com"
                    />
                  </div>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Address</label>
                <textarea
                  className="form-control"
                  rows="3"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Complete address including city, pin code"
                />
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">State</label>
                    <select
                      className="form-control"
                      value={formData.state_code}
                      onChange={(e) => setFormData({ ...formData, state_code: e.target.value })}
                    >
                      {Object.entries(STATE_CODES).map(([code, name]) => (
                        <option key={code} value={code}>
                          {code} - {name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">GSTIN</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.gstin}
                      onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                      placeholder="15-digit GSTIN (optional)"
                      maxLength="15"
                      style={{ fontFamily: 'monospace' }}
                    />
                    {formData.gstin && !validateGSTIN(formData.gstin) && (
                      <div style={{ color: '#e74c3c', fontSize: '0.8em', marginTop: '5px' }}>
                        Invalid GSTIN format
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="form-group text-right">
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={resetForm}
                  style={{ marginRight: '10px' }}
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  disabled={loading}
                >
                  {editingSupplier ? 'Update' : 'Add'} Supplier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Suppliers;
