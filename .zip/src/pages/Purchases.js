import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { v4 as uuidv4 } from 'uuid';
import { formatCurrency } from '../utils/gst';
import { formatQuantity } from '../utils/units';

const Purchases = () => {
  const { getAllRecords, insertRecord, updateRecord, deleteRecord, loading } = useDatabase();
  const [purchases, setPurchases] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [products, setProducts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingPurchase, setEditingPurchase] = useState(null);
  const [formData, setFormData] = useState({
    supplier_id: '',
    invoice_number: '',
    purchase_date: new Date().toISOString().split('T')[0],
    payment_status: 'pending',
    notes: ''
  });
  const [purchaseItems, setPurchaseItems] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [purchasesData, suppliersData, productsData] = await Promise.all([
        getAllRecords('purchases'),
        getAllRecords('suppliers'),
        getAllRecords('products')
      ]);
      setPurchases(purchasesData);
      setSuppliers(suppliersData);
      setProducts(productsData);
    } catch (error) {
      setMessage('Error loading data: ' + error.message);
    }
  };

  const addPurchaseItem = () => {
    setPurchaseItems([...purchaseItems, {
      id: uuidv4(),
      product_id: '',
      quantity: '',
      unit_price: ''
    }]);
  };

  const updatePurchaseItem = (itemId, field, value) => {
    setPurchaseItems(purchaseItems.map(item => {
      if (item.id === itemId) {
        const updatedItem = { ...item, [field]: value };
        
        // Auto-fill unit price when product is selected
        if (field === 'product_id' && value) {
          const product = products.find(p => p.id === value);
          if (product) {
            updatedItem.unit_price = product.purchase_price;
          }
        }
        
        return updatedItem;
      }
      return item;
    }));
  };

  const removePurchaseItem = (itemId) => {
    setPurchaseItems(purchaseItems.filter(item => item.id !== itemId));
  };

  const calculateTotal = () => {
    return purchaseItems.reduce((total, item) => {
      const quantity = parseFloat(item.quantity) || 0;
      const unitPrice = parseFloat(item.unit_price) || 0;
      return total + (quantity * unitPrice);
    }, 0);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.purchase_date) {
      setMessage('Purchase date is required');
      return;
    }

    if (purchaseItems.length === 0) {
      setMessage('At least one item is required');
      return;
    }

    // Validate purchase items
    for (const item of purchaseItems) {
      if (!item.product_id || !item.quantity || !item.unit_price) {
        setMessage('All purchase items must have product, quantity, and price');
        return;
      }
    }

    try {
      const totalAmount = calculateTotal();
      
      const purchaseData = {
        ...formData,
        total_amount: totalAmount
      };

      let purchaseId;
      
      if (editingPurchase) {
        await updateRecord('purchases', purchaseData, 'id = ?', [editingPurchase.id]);
        purchaseId = editingPurchase.id;
        
        // Delete existing purchase items
        await deleteRecord('purchase_items', 'purchase_id = ?', [purchaseId]);
        setMessage('Purchase updated successfully');
      } else {
        purchaseId = uuidv4();
        purchaseData.id = purchaseId;
        await insertRecord('purchases', purchaseData);
        setMessage('Purchase added successfully');
      }

      // Insert purchase items
      for (const item of purchaseItems) {
        const itemData = {
          id: uuidv4(),
          purchase_id: purchaseId,
          product_id: item.product_id,
          quantity: parseFloat(item.quantity),
          unit_price: parseFloat(item.unit_price),
          total_amount: parseFloat(item.quantity) * parseFloat(item.unit_price)
        };
        await insertRecord('purchase_items', itemData);
        
        // Update product stock
        const product = products.find(p => p.id === item.product_id);
        if (product) {
          const newStock = parseFloat(product.current_stock) + parseFloat(item.quantity);
          await updateRecord('products', { current_stock: newStock }, 'id = ?', [item.product_id]);
        }
      }
      
      resetForm();
      loadData();
    } catch (error) {
      setMessage('Error saving purchase: ' + error.message);
    }
  };

  const handleEdit = async (purchase) => {
    setEditingPurchase(purchase);
    setFormData({
      supplier_id: purchase.supplier_id || '',
      invoice_number: purchase.invoice_number || '',
      purchase_date: purchase.purchase_date,
      payment_status: purchase.payment_status,
      notes: purchase.notes || ''
    });
    
    // Load purchase items
    try {
      const items = await getAllRecords('purchase_items', 'purchase_id = ?', [purchase.id]);
      setPurchaseItems(items.map(item => ({
        id: item.id,
        product_id: item.product_id,
        quantity: item.quantity,
        unit_price: item.unit_price
      })));
    } catch (error) {
      console.error('Error loading purchase items:', error);
    }
    
    setShowModal(true);
  };

  const handleDelete = async (purchaseId) => {
    if (!window.confirm('Are you sure you want to delete this purchase?')) {
      return;
    }

    try {
      await deleteRecord('purchases', 'id = ?', [purchaseId]);
      setMessage('Purchase deleted successfully');
      loadData();
    } catch (error) {
      setMessage('Error deleting purchase: ' + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      supplier_id: '',
      invoice_number: '',
      purchase_date: new Date().toISOString().split('T')[0],
      payment_status: 'pending',
      notes: ''
    });
    setPurchaseItems([]);
    setEditingPurchase(null);
    setShowModal(false);
    setMessage('');
  };

  const getSupplierName = (supplierId) => {
    if (!supplierId) return 'Direct Purchase';
    const supplier = suppliers.find(s => s.id === supplierId);
    return supplier ? supplier.name : 'Unknown Supplier';
  };

  const getProductName = (productId) => {
    const product = products.find(p => p.id === productId);
    return product ? product.name : 'Unknown Product';
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Purchases</h1>
        <p className="page-subtitle">Manage purchase orders and inventory receipts</p>
      </div>

      {message && (
        <div className={`alert ${message.includes('Error') ? 'alert-error' : 'alert-success'}`}>
          {message}
        </div>
      )}

      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Purchase Orders</h3>
          <button 
            className="btn btn-primary"
            onClick={() => setShowModal(true)}
            disabled={loading}
          >
            New Purchase
          </button>
        </div>

        {purchases.length > 0 ? (
          <table className="table">
            <thead>
              <tr>
                <th>Invoice No.</th>
                <th>Supplier</th>
                <th>Date</th>
                <th>Total Amount</th>
                <th>Payment Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {purchases.map(purchase => (
                <tr key={purchase.id}>
                  <td>{purchase.invoice_number || 'No Invoice'}</td>
                  <td>{getSupplierName(purchase.supplier_id)}</td>
                  <td>{new Date(purchase.purchase_date).toLocaleDateString()}</td>
                  <td className="currency">{formatCurrency(purchase.total_amount)}</td>
                  <td>
                    <span className={`status ${purchase.payment_status}`}>
                      {purchase.payment_status}
                    </span>
                  </td>
                  <td>
                    <div className="table-actions">
                      <button 
                        className="btn btn-sm btn-warning"
                        onClick={() => handleEdit(purchase)}
                        disabled={loading}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn-sm btn-danger"
                        onClick={() => handleDelete(purchase.id)}
                        disabled={loading}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No purchases found. Click "New Purchase" to create your first purchase order.</p>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal">
          <div className="modal-content" style={{ maxWidth: '800px', maxHeight: '90vh' }}>
            <div className="modal-header">
              <h3 className="modal-title">
                {editingPurchase ? 'Edit Purchase' : 'New Purchase'}
              </h3>
              <button className="close-btn" onClick={resetForm}>×</button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Supplier</label>
                    <select
                      className="form-control"
                      value={formData.supplier_id}
                      onChange={(e) => setFormData({ ...formData, supplier_id: e.target.value })}
                    >
                      <option value="">Direct Purchase</option>
                      {suppliers.map(supplier => (
                        <option key={supplier.id} value={supplier.id}>
                          {supplier.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Invoice Number</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.invoice_number}
                      onChange={(e) => setFormData({ ...formData, invoice_number: e.target.value })}
                      placeholder="Supplier invoice number"
                    />
                  </div>
                </div>
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Purchase Date *</label>
                    <input
                      type="date"
                      className="form-control"
                      value={formData.purchase_date}
                      onChange={(e) => setFormData({ ...formData, purchase_date: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Payment Status</label>
                    <select
                      className="form-control"
                      value={formData.payment_status}
                      onChange={(e) => setFormData({ ...formData, payment_status: e.target.value })}
                    >
                      <option value="pending">Pending</option>
                      <option value="paid">Paid</option>
                      <option value="partial">Partial</option>
                      <option value="overdue">Overdue</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Purchase Items */}
              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <label className="form-label">Purchase Items</label>
                  <button 
                    type="button" 
                    className="btn btn-sm btn-success"
                    onClick={addPurchaseItem}
                  >
                    Add Item
                  </button>
                </div>
                
                {purchaseItems.map((item, index) => (
                  <div key={item.id} className="form-row" style={{ border: '1px solid #ddd', padding: '10px', margin: '10px 0', borderRadius: '5px' }}>
                    <div className="form-col">
                      <select
                        className="form-control"
                        value={item.product_id}
                        onChange={(e) => updatePurchaseItem(item.id, 'product_id', e.target.value)}
                        required
                      >
                        <option value="">Select Product</option>
                        {products.map(product => (
                          <option key={product.id} value={product.id}>
                            {product.name} (Current: {formatQuantity(product.current_stock, product.unit)})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="form-col">
                      <input
                        type="number"
                        step="0.01"
                        className="form-control"
                        placeholder="Quantity"
                        value={item.quantity}
                        onChange={(e) => updatePurchaseItem(item.id, 'quantity', e.target.value)}
                        required
                      />
                    </div>
                    <div className="form-col">
                      <input
                        type="number"
                        step="0.01"
                        className="form-control"
                        placeholder="Unit Price (₹)"
                        value={item.unit_price}
                        onChange={(e) => updatePurchaseItem(item.id, 'unit_price', e.target.value)}
                        required
                      />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <span style={{ marginRight: '10px', minWidth: '80px', textAlign: 'right' }}>
                        {formatCurrency((parseFloat(item.quantity) || 0) * (parseFloat(item.unit_price) || 0))}
                      </span>
                      <button 
                        type="button" 
                        className="btn btn-sm btn-danger"
                        onClick={() => removePurchaseItem(item.id)}
                      >
                        ×
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Total */}
              {purchaseItems.length > 0 && (
                <div className="form-group">
                  <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '5px', backgroundColor: '#f9f9f9' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', fontSize: '1.2em' }}>
                      <span>Total Amount:</span>
                      <span>{formatCurrency(calculateTotal())}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="form-group">
                <label className="form-label">Notes</label>
                <textarea
                  className="form-control"
                  rows="3"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Additional notes for this purchase"
                />
              </div>

              <div className="form-group text-right">
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={resetForm}
                  style={{ marginRight: '10px' }}
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  disabled={loading || purchaseItems.length === 0}
                >
                  {editingPurchase ? 'Update' : 'Create'} Purchase
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Purchases;
