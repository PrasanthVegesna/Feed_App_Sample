import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { v4 as uuidv4 } from 'uuid';
import { STATE_CODES, validateGSTIN } from '../utils/gst';

const Customers = () => {
  const { getAllRecords, insertRecord, updateRecord, deleteRecord, loading } = useDatabase();
  const [customers, setCustomers] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    gstin: '',
    state_code: '27'
  });
  const [message, setMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    try {
      const data = await getAllRecords('customers');
      setCustomers(data);
    } catch (error) {
      setMessage('Error loading customers: ' + error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      setMessage('Customer name is required');
      return;
    }

    // Validate GSTIN if provided
    if (formData.gstin && !validateGSTIN(formData.gstin)) {
      setMessage('Invalid GSTIN format');
      return;
    }

    try {
      if (editingCustomer) {
        await updateRecord('customers', formData, 'id = ?', [editingCustomer.id]);
        setMessage('Customer updated successfully');
      } else {
        const customerData = {
          id: uuidv4(),
          ...formData
        };
        await insertRecord('customers', customerData);
        setMessage('Customer added successfully');
      }
      
      resetForm();
      loadCustomers();
    } catch (error) {
      setMessage('Error saving customer: ' + error.message);
    }
  };

  const handleEdit = (customer) => {
    setEditingCustomer(customer);
    setFormData({
      name: customer.name,
      phone: customer.phone || '',
      email: customer.email || '',
      address: customer.address || '',
      gstin: customer.gstin || '',
      state_code: customer.state_code || '27'
    });
    setShowModal(true);
  };

  const handleDelete = async (customerId) => {
    if (!window.confirm('Are you sure you want to delete this customer?')) {
      return;
    }

    try {
      // Check if customer has sales
      const sales = await getAllRecords('sales', 'customer_id = ?', [customerId]);
      
      if (sales.length > 0) {
        setMessage(`Cannot delete customer. They have ${sales.length} sale(s) on record.`);
        return;
      }

      await deleteRecord('customers', 'id = ?', [customerId]);
      setMessage('Customer deleted successfully');
      loadCustomers();
    } catch (error) {
      setMessage('Error deleting customer: ' + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      phone: '',
      email: '',
      address: '',
      gstin: '',
      state_code: '27'
    });
    setEditingCustomer(null);
    setShowModal(false);
    setMessage('');
  };

  const getStateName = (stateCode) => {
    return STATE_CODES[stateCode] || 'Unknown State';
  };

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (customer.phone && customer.phone.includes(searchTerm)) ||
    (customer.email && customer.email.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Customers</h1>
        <p className="page-subtitle">Manage customer information and contacts</p>
      </div>

      {message && (
        <div className={`alert ${message.includes('Error') || message.includes('Cannot') ? 'alert-error' : 'alert-success'}`}>
          {message}
        </div>
      )}

      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Customer Directory</h3>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <input
              type="text"
              className="form-control"
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ width: '250px' }}
            />
            <button 
              className="btn btn-primary"
              onClick={() => setShowModal(true)}
              disabled={loading}
            >
              Add Customer
            </button>
          </div>
        </div>

        {filteredCustomers.length > 0 ? (
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Contact</th>
                <th>Location</th>
                <th>GSTIN</th>
                <th>Registration Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map(customer => (
                <tr key={customer.id}>
                  <td>
                    <strong>{customer.name}</strong>
                    {customer.email && (
                      <div style={{ fontSize: '0.8em', color: '#666' }}>
                        {customer.email}
                      </div>
                    )}
                  </td>
                  <td>
                    {customer.phone || 'No phone'}
                  </td>
                  <td>
                    {customer.address && (
                      <div style={{ fontSize: '0.9em' }}>
                        {customer.address}
                      </div>
                    )}
                    <div style={{ fontSize: '0.8em', color: '#666' }}>
                      {getStateName(customer.state_code)}
                    </div>
                  </td>
                  <td>
                    {customer.gstin ? (
                      <div style={{ fontFamily: 'monospace', fontSize: '0.9em' }}>
                        {customer.gstin}
                      </div>
                    ) : (
                      <span style={{ color: '#999' }}>Not provided</span>
                    )}
                  </td>
                  <td>{new Date(customer.created_at).toLocaleDateString()}</td>
                  <td>
                    <div className="table-actions">
                      <button 
                        className="btn btn-sm btn-warning"
                        onClick={() => handleEdit(customer)}
                        disabled={loading}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn-sm btn-danger"
                        onClick={() => handleDelete(customer.id)}
                        disabled={loading}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No customers found. {searchTerm ? 'Try a different search term or ' : ''}Click "Add Customer" to create your first customer.</p>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <div className="modal-header">
              <h3 className="modal-title">
                {editingCustomer ? 'Edit Customer' : 'Add New Customer'}
              </h3>
              <button className="close-btn" onClick={resetForm}>×</button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Customer Name *</label>
                <input
                  type="text"
                  className="form-control"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Phone Number</label>
                    <input
                      type="tel"
                      className="form-control"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="e.g., +91 9876543210"
                    />
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Email Address</label>
                    <input
                      type="email"
                      className="form-control"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="customer@example.com"
                    />
                  </div>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Address</label>
                <textarea
                  className="form-control"
                  rows="3"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Complete address including city, pin code"
                />
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">State</label>
                    <select
                      className="form-control"
                      value={formData.state_code}
                      onChange={(e) => setFormData({ ...formData, state_code: e.target.value })}
                    >
                      {Object.entries(STATE_CODES).map(([code, name]) => (
                        <option key={code} value={code}>
                          {code} - {name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">GSTIN</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.gstin}
                      onChange={(e) => setFormData({ ...formData, gstin: e.target.value.toUpperCase() })}
                      placeholder="15-digit GSTIN (optional)"
                      maxLength="15"
                      style={{ fontFamily: 'monospace' }}
                    />
                    {formData.gstin && !validateGSTIN(formData.gstin) && (
                      <div style={{ color: '#e74c3c', fontSize: '0.8em', marginTop: '5px' }}>
                        Invalid GSTIN format
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="form-group text-right">
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={resetForm}
                  style={{ marginRight: '10px' }}
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  disabled={loading}
                >
                  {editingCustomer ? 'Update' : 'Add'} Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Customers;
