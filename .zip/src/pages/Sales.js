import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { v4 as uuidv4 } from 'uuid';
import { calculateGST, calculateInvoiceTotal, formatCurrency } from '../utils/gst';
import { formatQuantity } from '../utils/units';

const Sales = () => {
  const { getAllRecords, insertRecord, updateRecord, deleteRecord, loading, settings } = useDatabase();
  const [sales, setSales] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingSale, setEditingSale] = useState(null);
  const [formData, setFormData] = useState({
    customer_id: '',
    invoice_number: '',
    sale_date: new Date().toISOString().split('T')[0],
    payment_status: 'pending',
    notes: ''
  });
  const [saleItems, setSaleItems] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [salesData, customersData, productsData] = await Promise.all([
        getAllRecords('sales'),
        getAllRecords('customers'),
        getAllRecords('products')
      ]);
      setSales(salesData);
      setCustomers(customersData);
      setProducts(productsData);
    } catch (error) {
      setMessage('Error loading data: ' + error.message);
    }
  };

  const generateInvoiceNumber = () => {
    const date = new Date();
    const year = date.getFullYear().toString().substr(-2);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `INV${year}${month}${random}`;
  };

  const addSaleItem = () => {
    setSaleItems([...saleItems, {
      id: uuidv4(),
      product_id: '',
      quantity: '',
      unit_price: '',
      gst_rate: 18
    }]);
  };

  const updateSaleItem = (itemId, field, value) => {
    setSaleItems(saleItems.map(item => {
      if (item.id === itemId) {
        const updatedItem = { ...item, [field]: value };
        
        // Auto-fill unit price and GST rate when product is selected
        if (field === 'product_id' && value) {
          const product = products.find(p => p.id === value);
          if (product) {
            updatedItem.unit_price = product.selling_price;
            updatedItem.gst_rate = product.gst_rate;
          }
        }
        
        return updatedItem;
      }
      return item;
    }));
  };

  const removeSaleItem = (itemId) => {
    setSaleItems(saleItems.filter(item => item.id !== itemId));
  };

  const calculateTotals = () => {
    const companyStateCode = settings.state_code || '27';
    const customer = customers.find(c => c.id === formData.customer_id);
    const customerStateCode = customer?.state_code || companyStateCode;
    
    return calculateInvoiceTotal(
      saleItems.map(item => ({
        quantity: parseFloat(item.quantity) || 0,
        unit_price: parseFloat(item.unit_price) || 0,
        gst_rate: parseFloat(item.gst_rate) || 0
      })),
      companyStateCode,
      customerStateCode
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.invoice_number.trim()) {
      setMessage('Invoice number is required');
      return;
    }

    if (saleItems.length === 0) {
      setMessage('At least one item is required');
      return;
    }

    // Validate sale items
    for (const item of saleItems) {
      if (!item.product_id || !item.quantity || !item.unit_price) {
        setMessage('All sale items must have product, quantity, and price');
        return;
      }
    }

    try {
      const totals = calculateTotals();
      
      const saleData = {
        ...formData,
        subtotal: totals.subtotal,
        cgst_amount: totals.cgst,
        sgst_amount: totals.sgst,
        igst_amount: totals.igst,
        total_amount: totals.grandTotal
      };

      let saleId;
      
      if (editingSale) {
        await updateRecord('sales', saleData, 'id = ?', [editingSale.id]);
        saleId = editingSale.id;
        
        // Delete existing sale items
        await deleteRecord('sale_items', 'sale_id = ?', [saleId]);
        setMessage('Sale updated successfully');
      } else {
        saleId = uuidv4();
        saleData.id = saleId;
        await insertRecord('sales', saleData);
        setMessage('Sale added successfully');
      }

      // Insert sale items
      for (const item of saleItems) {
        const itemData = {
          id: uuidv4(),
          sale_id: saleId,
          product_id: item.product_id,
          quantity: parseFloat(item.quantity),
          unit_price: parseFloat(item.unit_price),
          gst_rate: parseFloat(item.gst_rate),
          total_amount: parseFloat(item.quantity) * parseFloat(item.unit_price)
        };
        await insertRecord('sale_items', itemData);
        
        // Update product stock
        const product = products.find(p => p.id === item.product_id);
        if (product) {
          const newStock = parseFloat(product.current_stock) - parseFloat(item.quantity);
          await updateRecord('products', { current_stock: newStock }, 'id = ?', [item.product_id]);
        }
      }
      
      resetForm();
      loadData();
    } catch (error) {
      setMessage('Error saving sale: ' + error.message);
    }
  };

  const handleEdit = async (sale) => {
    setEditingSale(sale);
    setFormData({
      customer_id: sale.customer_id || '',
      invoice_number: sale.invoice_number,
      sale_date: sale.sale_date,
      payment_status: sale.payment_status,
      notes: sale.notes || ''
    });
    
    // Load sale items
    try {
      const items = await getAllRecords('sale_items', 'sale_id = ?', [sale.id]);
      setSaleItems(items.map(item => ({
        id: item.id,
        product_id: item.product_id,
        quantity: item.quantity,
        unit_price: item.unit_price,
        gst_rate: item.gst_rate
      })));
    } catch (error) {
      console.error('Error loading sale items:', error);
    }
    
    setShowModal(true);
  };

  const handleDelete = async (saleId) => {
    if (!window.confirm('Are you sure you want to delete this sale?')) {
      return;
    }

    try {
      await deleteRecord('sales', 'id = ?', [saleId]);
      setMessage('Sale deleted successfully');
      loadData();
    } catch (error) {
      setMessage('Error deleting sale: ' + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      customer_id: '',
      invoice_number: '',
      sale_date: new Date().toISOString().split('T')[0],
      payment_status: 'pending',
      notes: ''
    });
    setSaleItems([]);
    setEditingSale(null);
    setShowModal(false);
    setMessage('');
  };

  const getCustomerName = (customerId) => {
    if (!customerId) return 'Walk-in Customer';
    const customer = customers.find(c => c.id === customerId);
    return customer ? customer.name : 'Unknown Customer';
  };

  const getProductName = (productId) => {
    const product = products.find(p => p.id === productId);
    return product ? product.name : 'Unknown Product';
  };

  const totals = calculateTotals();

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Sales</h1>
        <p className="page-subtitle">Manage sales transactions and invoices</p>
      </div>

      {message && (
        <div className={`alert ${message.includes('Error') ? 'alert-error' : 'alert-success'}`}>
          {message}
        </div>
      )}

      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Sales Transactions</h3>
          <button 
            className="btn btn-primary"
            onClick={() => {
              setFormData({
                ...formData,
                invoice_number: generateInvoiceNumber()
              });
              setShowModal(true);
            }}
            disabled={loading}
          >
            New Sale
          </button>
        </div>

        {sales.length > 0 ? (
          <table className="table">
            <thead>
              <tr>
                <th>Invoice No.</th>
                <th>Customer</th>
                <th>Date</th>
                <th>Total Amount</th>
                <th>Payment Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sales.map(sale => (
                <tr key={sale.id}>
                  <td><strong>{sale.invoice_number}</strong></td>
                  <td>{getCustomerName(sale.customer_id)}</td>
                  <td>{new Date(sale.sale_date).toLocaleDateString()}</td>
                  <td className="currency">{formatCurrency(sale.total_amount)}</td>
                  <td>
                    <span className={`status ${sale.payment_status}`}>
                      {sale.payment_status}
                    </span>
                  </td>
                  <td>
                    <div className="table-actions">
                      <button 
                        className="btn btn-sm btn-warning"
                        onClick={() => handleEdit(sale)}
                        disabled={loading}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn-sm btn-danger"
                        onClick={() => handleDelete(sale.id)}
                        disabled={loading}
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No sales found. Click "New Sale" to create your first sale.</p>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal">
          <div className="modal-content" style={{ maxWidth: '800px', maxHeight: '90vh' }}>
            <div className="modal-header">
              <h3 className="modal-title">
                {editingSale ? 'Edit Sale' : 'New Sale'}
              </h3>
              <button className="close-btn" onClick={resetForm}>×</button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Invoice Number *</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.invoice_number}
                      onChange={(e) => setFormData({ ...formData, invoice_number: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Sale Date *</label>
                    <input
                      type="date"
                      className="form-control"
                      value={formData.sale_date}
                      onChange={(e) => setFormData({ ...formData, sale_date: e.target.value })}
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Customer</label>
                    <select
                      className="form-control"
                      value={formData.customer_id}
                      onChange={(e) => setFormData({ ...formData, customer_id: e.target.value })}
                    >
                      <option value="">Walk-in Customer</option>
                      {customers.map(customer => (
                        <option key={customer.id} value={customer.id}>
                          {customer.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Payment Status</label>
                    <select
                      className="form-control"
                      value={formData.payment_status}
                      onChange={(e) => setFormData({ ...formData, payment_status: e.target.value })}
                    >
                      <option value="pending">Pending</option>
                      <option value="paid">Paid</option>
                      <option value="partial">Partial</option>
                      <option value="overdue">Overdue</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Sale Items */}
              <div className="form-group">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <label className="form-label">Sale Items</label>
                  <button 
                    type="button" 
                    className="btn btn-sm btn-success"
                    onClick={addSaleItem}
                  >
                    Add Item
                  </button>
                </div>
                
                {saleItems.map((item, index) => (
                  <div key={item.id} className="form-row" style={{ border: '1px solid #ddd', padding: '10px', margin: '10px 0', borderRadius: '5px' }}>
                    <div className="form-col">
                      <select
                        className="form-control"
                        value={item.product_id}
                        onChange={(e) => updateSaleItem(item.id, 'product_id', e.target.value)}
                        required
                      >
                        <option value="">Select Product</option>
                        {products.map(product => (
                          <option key={product.id} value={product.id}>
                            {product.name} ({formatQuantity(product.current_stock, product.unit)} available)
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="form-col">
                      <input
                        type="number"
                        step="0.01"
                        className="form-control"
                        placeholder="Quantity"
                        value={item.quantity}
                        onChange={(e) => updateSaleItem(item.id, 'quantity', e.target.value)}
                        required
                      />
                    </div>
                    <div className="form-col">
                      <input
                        type="number"
                        step="0.01"
                        className="form-control"
                        placeholder="Unit Price (₹)"
                        value={item.unit_price}
                        onChange={(e) => updateSaleItem(item.id, 'unit_price', e.target.value)}
                        required
                      />
                    </div>
                    <div className="form-col">
                      <input
                        type="number"
                        step="0.01"
                        className="form-control"
                        placeholder="GST %"
                        value={item.gst_rate}
                        onChange={(e) => updateSaleItem(item.id, 'gst_rate', e.target.value)}
                      />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <button 
                        type="button" 
                        className="btn btn-sm btn-danger"
                        onClick={() => removeSaleItem(item.id)}
                      >
                        ×
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Totals */}
              {saleItems.length > 0 && (
                <div className="form-group">
                  <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '5px', backgroundColor: '#f9f9f9' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span>Subtotal:</span>
                      <span>{formatCurrency(totals.subtotal)}</span>
                    </div>
                    {totals.cgst > 0 && (
                      <>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>CGST:</span>
                          <span>{formatCurrency(totals.cgst)}</span>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <span>SGST:</span>
                          <span>{formatCurrency(totals.sgst)}</span>
                        </div>
                      </>
                    )}
                    {totals.igst > 0 && (
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span>IGST:</span>
                        <span>{formatCurrency(totals.igst)}</span>
                      </div>
                    )}
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', borderTop: '1px solid #ddd', paddingTop: '10px', marginTop: '10px' }}>
                      <span>Grand Total:</span>
                      <span>{formatCurrency(totals.grandTotal)}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="form-group">
                <label className="form-label">Notes</label>
                <textarea
                  className="form-control"
                  rows="3"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Additional notes for this sale"
                />
              </div>

              <div className="form-group text-right">
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={resetForm}
                  style={{ marginRight: '10px' }}
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  disabled={loading || saleItems.length === 0}
                >
                  {editingSale ? 'Update' : 'Create'} Sale
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sales;
