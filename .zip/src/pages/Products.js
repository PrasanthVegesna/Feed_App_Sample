import React, { useState, useEffect } from 'react';
import { useDatabase } from '../context/DatabaseContext';
import { v4 as uuidv4 } from 'uuid';
import { UNITS, getUnitLabel, formatQuantity } from '../utils/units';
import { GST_RATES, HSN_CODES, formatCurrency } from '../utils/gst';

const Products = () => {
  const { getAllRecords, insertRecord, updateRecord, deleteRecord, loading } = useDatabase();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    category_id: '',
    unit: 'kg',
    purchase_price: '',
    selling_price: '',
    current_stock: '',
    min_stock_level: '',
    gst_rate: '18',
    hsn_code: ''
  });
  const [message, setMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [productsData, categoriesData] = await Promise.all([
        getAllRecords('products'),
        getAllRecords('categories')
      ]);
      setProducts(productsData);
      setCategories(categoriesData);
    } catch (error) {
      setMessage('Error loading data: ' + error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      setMessage('Product name is required');
      return;
    }

    try {
      const productData = {
        ...formData,
        purchase_price: parseFloat(formData.purchase_price) || 0,
        selling_price: parseFloat(formData.selling_price) || 0,
        current_stock: parseFloat(formData.current_stock) || 0,
        min_stock_level: parseFloat(formData.min_stock_level) || 0,
        gst_rate: parseFloat(formData.gst_rate) || 0,
        category_id: formData.category_id || null,
        hsn_code: formData.hsn_code || null
      };

      if (editingProduct) {
        await updateRecord('products', productData, 'id = ?', [editingProduct.id]);
        setMessage('Product updated successfully');
      } else {
        productData.id = uuidv4();
        await insertRecord('products', productData);
        setMessage('Product added successfully');
      }
      
      resetForm();
      loadData();
    } catch (error) {
      setMessage('Error saving product: ' + error.message);
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      category_id: product.category_id || '',
      unit: product.unit,
      purchase_price: product.purchase_price,
      selling_price: product.selling_price,
      current_stock: product.current_stock,
      min_stock_level: product.min_stock_level,
      gst_rate: product.gst_rate,
      hsn_code: product.hsn_code || ''
    });
    setShowModal(true);
  };

  const handleDelete = async (productId) => {
    if (!window.confirm('Are you sure you want to delete this product?')) {
      return;
    }

    try {
      await deleteRecord('products', 'id = ?', [productId]);
      setMessage('Product deleted successfully');
      loadData();
    } catch (error) {
      setMessage('Error deleting product: ' + error.message);
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      category_id: '',
      unit: 'kg',
      purchase_price: '',
      selling_price: '',
      current_stock: '',
      min_stock_level: '',
      gst_rate: '18',
      hsn_code: ''
    });
    setEditingProduct(null);
    setShowModal(false);
    setMessage('');
  };

  const getCategoryName = (categoryId) => {
    const category = categories.find(c => c.id === categoryId);
    return category ? category.name : 'Uncategorized';
  };

  const getStockStatus = (currentStock, minLevel) => {
    const current = parseFloat(currentStock);
    const min = parseFloat(minLevel);
    
    if (current <= 0) return { status: 'Out of Stock', color: '#e74c3c' };
    if (current <= min) return { status: 'Low Stock', color: '#f39c12' };
    return { status: 'In Stock', color: '#27ae60' };
  };

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    getCategoryName(product.category_id).toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Products</h1>
        <p className="page-subtitle">Manage your inventory products</p>
      </div>

      {message && (
        <div className={`alert ${message.includes('Error') ? 'alert-error' : 'alert-success'}`}>
          {message}
        </div>
      )}

      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Product Inventory</h3>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <input
              type="text"
              className="form-control"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              style={{ width: '250px' }}
            />
            <button 
              className="btn btn-primary"
              onClick={() => setShowModal(true)}
              disabled={loading}
            >
              Add Product
            </button>
          </div>
        </div>

        {filteredProducts.length > 0 ? (
          <table className="table">
            <thead>
              <tr>
                <th>Product Name</th>
                <th>Category</th>
                <th>Stock</th>
                <th>Unit</th>
                <th>Purchase Price</th>
                <th>Selling Price</th>
                <th>GST Rate</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredProducts.map(product => {
                const stockStatus = getStockStatus(product.current_stock, product.min_stock_level);
                return (
                  <tr key={product.id}>
                    <td>
                      <strong>{product.name}</strong>
                      {product.hsn_code && (
                        <div style={{ fontSize: '0.8em', color: '#666' }}>
                          HSN: {product.hsn_code}
                        </div>
                      )}
                    </td>
                    <td>{getCategoryName(product.category_id)}</td>
                    <td>
                      {formatQuantity(product.current_stock, product.unit)}
                      <div style={{ fontSize: '0.8em', color: '#666' }}>
                        Min: {formatQuantity(product.min_stock_level, product.unit)}
                      </div>
                    </td>
                    <td>{getUnitLabel(product.unit)}</td>
                    <td className="currency">{formatCurrency(product.purchase_price)}</td>
                    <td className="currency">{formatCurrency(product.selling_price)}</td>
                    <td>{product.gst_rate}%</td>
                    <td>
                      <span style={{ color: stockStatus.color, fontWeight: 'bold' }}>
                        {stockStatus.status}
                      </span>
                    </td>
                    <td>
                      <div className="table-actions">
                        <button 
                          className="btn btn-sm btn-warning"
                          onClick={() => handleEdit(product)}
                          disabled={loading}
                        >
                          Edit
                        </button>
                        <button 
                          className="btn btn-sm btn-danger"
                          onClick={() => handleDelete(product.id)}
                          disabled={loading}
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <p>No products found. {searchTerm ? 'Try a different search term or ' : ''}Click "Add Product" to create your first product.</p>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="modal">
          <div className="modal-content" style={{ maxWidth: '600px' }}>
            <div className="modal-header">
              <h3 className="modal-title">
                {editingProduct ? 'Edit Product' : 'Add New Product'}
              </h3>
              <button className="close-btn" onClick={resetForm}>×</button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Product Name *</label>
                    <input
                      type="text"
                      className="form-control"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Category</label>
                    <select
                      className="form-control"
                      value={formData.category_id}
                      onChange={(e) => setFormData({ ...formData, category_id: e.target.value })}
                    >
                      <option value="">Select Category</option>
                      {categories.map(category => (
                        <option key={category.id} value={category.id}>
                          {category.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Unit</label>
                    <select
                      className="form-control"
                      value={formData.unit}
                      onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    >
                      {UNITS.map(unit => (
                        <option key={unit.value} value={unit.value}>
                          {unit.label}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">HSN Code</label>
                    <select
                      className="form-control"
                      value={formData.hsn_code}
                      onChange={(e) => setFormData({ ...formData, hsn_code: e.target.value })}
                    >
                      <option value="">Select HSN Code</option>
                      {HSN_CODES.map(hsn => (
                        <option key={hsn.code} value={hsn.code}>
                          {hsn.code} - {hsn.description}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Purchase Price (₹)</label>
                    <input
                      type="number"
                      step="0.01"
                      className="form-control"
                      value={formData.purchase_price}
                      onChange={(e) => setFormData({ ...formData, purchase_price: e.target.value })}
                    />
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Selling Price (₹)</label>
                    <input
                      type="number"
                      step="0.01"
                      className="form-control"
                      value={formData.selling_price}
                      onChange={(e) => setFormData({ ...formData, selling_price: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div className="form-row">
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Current Stock</label>
                    <input
                      type="number"
                      step="0.01"
                      className="form-control"
                      value={formData.current_stock}
                      onChange={(e) => setFormData({ ...formData, current_stock: e.target.value })}
                    />
                  </div>
                </div>
                <div className="form-col">
                  <div className="form-group">
                    <label className="form-label">Min Stock Level</label>
                    <input
                      type="number"
                      step="0.01"
                      className="form-control"
                      value={formData.min_stock_level}
                      onChange={(e) => setFormData({ ...formData, min_stock_level: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">GST Rate (%)</label>
                <select
                  className="form-control"
                  value={formData.gst_rate}
                  onChange={(e) => setFormData({ ...formData, gst_rate: e.target.value })}
                >
                  {GST_RATES.map(rate => (
                    <option key={rate} value={rate}>{rate}%</option>
                  ))}
                </select>
              </div>

              <div className="form-group text-right">
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={resetForm}
                  style={{ marginRight: '10px' }}
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="btn btn-primary"
                  disabled={loading}
                >
                  {editingProduct ? 'Update' : 'Add'} Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Products;
