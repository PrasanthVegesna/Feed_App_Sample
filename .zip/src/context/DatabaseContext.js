import React, { createContext, useContext, useState, useEffect } from 'react';

const DatabaseContext = createContext();

export const useDatabase = () => {
  const context = useContext(DatabaseContext);
  if (!context) {
    throw new Error('useDatabase must be used within a DatabaseProvider');
  }
  return context;
};

export const DatabaseProvider = ({ children }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [settings, setSettings] = useState({});

  // Database operations
  const executeQuery = async (query, params = []) => {
    try {
      setLoading(true);
      setError(null);
      // Use Electron API 
      const result = await window.electronAPI.dbExecuteQuery(query, params);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const getAllRecords = async (table, whereClause = '', params = []) => {
    try {
      setLoading(true);
      setError(null);
      const result = await window.electronAPI.dbGetAll(table, whereClause, params);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const insertRecord = async (table, data) => {
    try {
      setLoading(true);
      setError(null);
      const result = await window.electronAPI.dbInsert(table, data);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const updateRecord = async (table, data, whereClause, params = []) => {
    try {
      setLoading(true);
      setError(null);
      const result = await window.electronAPI.dbUpdate(table, data, whereClause, params);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const deleteRecord = async (table, whereClause, params = []) => {
    try {
      setLoading(true);
      setError(null);
      const result = await window.electronAPI.dbDelete(table, whereClause, params);
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // MongoDB operations
  const syncToMongoDB = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await window.electronAPI.mongoSync();
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const restoreFromMongoDB = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await window.electronAPI.mongoRestore();
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const testMongoConnection = async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await window.electronAPI.mongoTest();
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Load settings on mount
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const settingsData = await getAllRecords('settings');
        const settingsObj = {};
        settingsData.forEach(setting => {
          settingsObj[setting.key] = setting.value;
        });
        setSettings(settingsObj);
      } catch (err) {
        console.error('Failed to load settings:', err);
      }
    };

    loadSettings();
  }, []);

  const value = {
    loading,
    error,
    settings,
    setSettings,
    executeQuery,
    getAllRecords,
    insertRecord,
    updateRecord,
    deleteRecord,
    syncToMongoDB,
    restoreFromMongoDB,
    testMongoConnection
  };

  return (
    <DatabaseContext.Provider value={value}>
      {children}
    </DatabaseContext.Provider>
  );
};
